import express, { Request, Response } from 'express';

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Hotel currency standard
const CURRENCY = 'Ksh';

// Mock in-memory store for standalone execution (connects to MySQL in production)
const guests = [
  { id: 1, full_name: 'Lady Eleanor Vance', email: 'eleanor.vance@vanceholdings.co.uk', vip_tier: 'Platinum' }
];

const rooms = [
  { id: 101, room_number: '101', room_type: 'Standard', price: 95.0, status: 'Available' },
  { id: 201, room_number: '201', room_type: 'Deluxe', price: 165.0, status: 'Available' },
  { id: 501, room_number: '501', room_type: 'Penthouse', price: 850.0, status: 'Available' }
];

// Guest Signup Endpoint
app.post('/api/guest/signup', (req: Request, res: Response) => {
  const { full_name, email, password, phone, id_passport, address } = req.body;
  if (!full_name || !email || !password) {
    return res.status(400).json({ error: 'Full name, email, and password required' });
  }

  const newGuest = {
    id: guests.length + 1,
    full_name,
    email,
    phone: phone || '',
    id_passport: id_passport || '',
    address: address || '',
    vip_tier: 'Standard'
  };
  guests.push(newGuest);

  return res.status(201).json({
    message: 'Guest account created successfully',
    guest: newGuest,
    currency: CURRENCY
  });
});

// Guest Login Endpoint
app.post('/api/guest/login', (req: Request, res: Response) => {
  const { email, password } = req.body;
  const guest = guests.find(g => g.email.toLowerCase() === (email || '').toLowerCase());
  if (!guest) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }
  return res.json({ message: 'Authentication successful', guest, currency: CURRENCY });
});

// Rooms List Endpoint
app.get('/api/rooms', (_req: Request, res: Response) => {
  res.json({ currency: CURRENCY, rooms });
});

app.listen(PORT, () => {
  console.log(`Grand Aurelia HMS Express Server listening on port ${PORT} (Currency: ${CURRENCY})`);
});
