# Grand Aurelia - Hotel Management System (HMS)
**Enterprise Hospitality Property Management System (PMS), Guest Self-Service Portal & Relational Database**

Developed with support for:
* **HTML Document Schemes**: Printable Guest Folios, Booking Confirmation Slips, Housekeeping Turnover Run Sheets, and Night Audit Financial Reports in Kenyan Shillings (Ksh).
* **MySQL Database**: Full relational schema with tables for Rooms, Guests, Guest Accounts (Auth), Reservations, Billing Items, and Housekeeping Tasks.
* **Guest Authentication & Self-Service**: Guest signup, secure login, personal booking itinerary, and 1-click HTML receipt download.
* **Multi-Stack Backend Ready**: Includes runnable **Python (Flask)** and **Node.js (Express)** backend implementations.

---

## 📁 Project Directory Structure
```
hotel_management_system/
├── README.md                           # Main setup & architecture guide
├── database/
│   ├── hotel_db_schema.sql             # Production MySQL database schema + initial seed data (Ksh)
│   └── schema_documentation.md         # Database dictionary and Entity Relationship Diagram (ERD)
├── html_schemes/
│   ├── guest_folio_scheme.html         # Printable guest invoice / folio template (Ksh)
│   ├── booking_confirmation_scheme.html # Official booking confirmation slip template
│   ├── housekeeping_run_scheme.html    # Daily housekeeping turnover checklist
│   ├── night_audit_scheme.html         # Night audit daily financial reconciliation
│   └── guest_portal_scheme.html        # Guest self-service portal layout
├── backend_python_flask/
│   ├── app.py                          # Flask application with guest auth, booking CRUD & HTML rendering
│   ├── database.py                     # SQLite / MySQL database abstraction layer
│   └── requirements.txt                # Python dependencies (Flask, mysql-connector-python)
├── backend_nodejs_express/
│   ├── server.ts                       # Express REST API for guest auth, reservations & rooms
│   └── package.json                    # Node dependencies
└── quickstart.sh                       # Quick launch script
```

---

## 🚀 Quick Setup Instructions

### Option A: MySQL Database Setup
1. Open your MySQL client (MySQL Workbench, phpMyAdmin, or terminal CLI):
   ```bash
   mysql -u root -p < database/hotel_db_schema.sql
   ```
2. This creates the `hotel_db` database and loads:
   - 10 luxury hotel rooms across 5 room types (rates in Ksh)
   - 5 guest records with loyalty VIP tiers
   - 5 guest login accounts
   - Active reservations & itemized billing records
   - Housekeeping assignments

### Option B: Running the Python Flask Backend
1. Navigate to the Python backend directory:
   ```bash
   cd backend_python_flask
   ```
2. Create and activate a virtual environment:
   ```bash
   python -m venv venv
   # On Windows:
   venv\Scripts\activate
   # On macOS/Linux:
   source venv/bin/activate
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Start the application:
   ```bash
   python app.py
   ```
5. Open your browser at `http://127.0.0.1:5000`

### Option C: Running the Node.js / Express Backend
1. Navigate to the Node backend directory:
   ```bash
   cd backend_nodejs_express
   npm install
   npm start
   ```
2. Server runs at `http://localhost:3000`

---

## 👤 Guest Accounts (Default Test Credentials)
| Email | Password | Guest Name | VIP Tier |
|---|---|---|---|
| `eleanor.vance@vanceholdings.co.uk` | `password123` | Lady Eleanor Vance | Platinum |
| `m.sterling@biogenix-research.org` | `password123` | Dr. Marcus Sterling | Gold |
| `sophia@laurent-design.fr` | `password123` | Sophia Laurent | Silver |
| `kenji.takahashi@omni-tokyo.jp` | `password123` | Kenji Takahashi | Standard |
| `a.okafor@africavc.com` | `password123` | Amara Okafor | Gold |

*New guests can also sign up immediately via the Guest Self-Service Portal.*

---

## 📄 HTML Schemes & Printing
All HTML templates are self-contained with:
* High-resolution typography & embedded luxury CSS
* Built-in `@media print` rules for clean paper or PDF printing
* Hotel tax registration, currency formatted in Ksh (KES)
