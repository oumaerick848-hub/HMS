# MySQL Database Schema Documentation - Grand Aurelia HMS

## Database: `hotel_db`
Default Charset: `utf8mb4`
Engine: `InnoDB`
Currency Standard: `KES` (Kenyan Shilling - Ksh)

---

### Tables Summary

#### 1. `rooms`
Stores hotel inventory, pricing per night in Ksh, capacity, and current operational status.
* `id`: INT(11) AUTO_INCREMENT PRIMARY KEY
* `room_number`: VARCHAR(10) UNIQUE NOT NULL (e.g. '101', '501')
* `room_type`: ENUM('Standard','Deluxe','Executive Suite','Presidential Suite','Penthouse')
* `price`: DECIMAL(10,2) NOT NULL (Price per night in Ksh)
* `floor`: INT(11) NOT NULL
* `status`: VARCHAR(20) DEFAULT 'Available' ('Available','Booked','Occupied','Cleaning','Maintenance')
* `bed_type`: VARCHAR(50)
* `max_guests`: INT(11) DEFAULT 2
* `amenities`: TEXT
* `description`: TEXT

#### 2. `guests`
CRM profiles containing guest identity, contact information, VIP tier, and stay preferences.
* `id`: INT(11) AUTO_INCREMENT PRIMARY KEY
* `full_name`: VARCHAR(100) NOT NULL
* `email`: VARCHAR(100) INDEX
* `phone`: VARCHAR(30)
* `id_passport`: VARCHAR(50) (National ID or Passport number)
* `address`: TEXT
* `vip_tier`: ENUM('Standard','Silver','Gold','Platinum') DEFAULT 'Standard'
* `notes`: TEXT
* `created_at`: DATETIME DEFAULT CURRENT_TIMESTAMP

#### 3. `guest_accounts`
Secure credentials for Guest Self-Service Portal access.
* `id`: INT(11) AUTO_INCREMENT PRIMARY KEY
* `guest_id`: INT(11) NOT NULL (FOREIGN KEY -> `guests.id` ON DELETE CASCADE)
* `email`: VARCHAR(100) UNIQUE NOT NULL
* `password_hash`: VARCHAR(255) NOT NULL
* `created_at`: DATETIME DEFAULT CURRENT_TIMESTAMP

#### 4. `bookings`
Reservations linking guests to specific rooms, tracking arrival/departure, rates, and payments.
* `id`: INT(11) AUTO_INCREMENT PRIMARY KEY
* `booking_code`: VARCHAR(20) UNIQUE NOT NULL (e.g. 'AURELIA-7821')
* `guest_id`: INT(11) NOT NULL (FOREIGN KEY -> `guests.id`)
* `room_id`: INT(11) NOT NULL (FOREIGN KEY -> `rooms.id`)
* `check_in`: DATE NOT NULL
* `check_out`: DATE NOT NULL
* `adults`: INT(11) DEFAULT 1
* `children`: INT(11) DEFAULT 0
* `total_amount`: DECIMAL(10,2) NOT NULL (Total stay in Ksh)
* `paid_amount`: DECIMAL(10,2) DEFAULT 0.00
* `status`: VARCHAR(20) DEFAULT 'Confirmed' ('Confirmed','Checked-In','Checked-Out','Cancelled')
* `payment_method`: VARCHAR(30) DEFAULT 'Credit Card'
* `notes`: TEXT
* `created_at`: DATETIME DEFAULT CURRENT_TIMESTAMP

#### 5. `billing_items`
Itemized line-item charges posted against a folio (Room charges, Restaurant & Bar, Spa, Incidentals).
* `id`: INT(11) AUTO_INCREMENT PRIMARY KEY
* `booking_id`: INT(11) NOT NULL (FOREIGN KEY -> `bookings.id` ON DELETE CASCADE)
* `description`: VARCHAR(255) NOT NULL
* `category`: VARCHAR(50) NOT NULL
* `amount`: DECIMAL(10,2) NOT NULL (in Ksh)
* `item_date`: DATE NOT NULL

#### 6. `housekeeping_tasks`
Housekeeping tasks, sanitization, room turns, and inspection workflows.
* `id`: INT(11) AUTO_INCREMENT PRIMARY KEY
* `room_id`: INT(11) NOT NULL (FOREIGN KEY -> `rooms.id` ON DELETE CASCADE)
* `assigned_to`: VARCHAR(100)
* `task_status`: VARCHAR(30) DEFAULT 'Pending' ('Pending','In Progress','Completed','Inspected')
* `priority`: VARCHAR(20) DEFAULT 'Medium' ('High','Medium','Low')
* `notes`: TEXT
* `scheduled_date`: DATE
