-- ========================================================
-- GRAND AURELIA RESORT & SUITES — SYSTEM DATA EXPORT
-- Standalone Executable SQL Script (.sql)
-- Generated at: 2026-10-05T07:55:23.719Z
-- Dialect Target: MySQL 8.0
-- Database Target: `hotel_db`
-- Storage Engine: InnoDB (ACID Compliant)
-- Primary Currency: KES (Kenyan Shilling - Ksh)
-- Total Packaged Tables: 11
-- Packaging Components:
--   1. Full Relational Schema Configurations & Constraints
--   2. Complete Database State (Inventory, Guests, Bookings, Incidentals)
--   3. System Audit Trails & SQL Execution Logs (sql_audit_logs)
--   4. Global System Configuration Parameters (system_schema_metadata)
-- Full Data Portability Guaranteed for System Administrators
-- ========================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

CREATE DATABASE IF NOT EXISTS `hotel_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `hotel_db`;

-- --------------------------------------------------------
-- Section 0: Clean Idempotent Drop Directives
-- --------------------------------------------------------
DROP TABLE IF EXISTS `guest_feedbacks`;
DROP TABLE IF EXISTS `admin_notification_alerts`;
DROP TABLE IF EXISTS `notifications`;
DROP TABLE IF EXISTS `housekeeping_tasks`;
DROP TABLE IF EXISTS `billing_items`;
DROP TABLE IF EXISTS `bookings`;
DROP TABLE IF EXISTS `guest_accounts`;
DROP TABLE IF EXISTS `guests`;
DROP TABLE IF EXISTS `rooms`;
DROP TABLE IF EXISTS `sql_audit_logs`;
DROP TABLE IF EXISTS `system_schema_metadata`;

-- --------------------------------------------------------
-- Table structure & configuration for: `system_schema_metadata`
-- --------------------------------------------------------
CREATE TABLE `system_schema_metadata` (
  `key_name` VARCHAR(100) NOT NULL,
  `config_value` TEXT NOT NULL,
  `category` VARCHAR(50) NOT NULL,
  `description` VARCHAR(255) DEFAULT NULL,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`key_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping system schema configurations
INSERT INTO `system_schema_metadata` (`key_name`, `config_value`, `category`, `description`, `updated_at`) VALUES
('system_name', 'Grand Aurelia Hotel Management System', 'Core', 'Primary application and property identity', '2026-10-05T07:55:23.719Z'),
('system_version', '4.2.0-Enterprise', 'Core', 'Installed PMS software version', '2026-10-05T07:55:23.719Z'),
('database_name', 'hotel_db', 'Database', 'Active relational database catalog', '2026-10-05T07:55:23.719Z'),
('default_storage_engine', 'InnoDB', 'Database', 'Transactional engine with ACID and row-level locking', '2026-10-05T07:55:23.719Z'),
('character_set', 'utf8mb4', 'Encoding', 'Multilingual UTF-8 with full emoji & surrogate pair support', '2026-10-05T07:55:23.719Z'),
('collation', 'utf8mb4_unicode_ci', 'Encoding', 'Unicode collation for accurate case-insensitive matching', '2026-10-05T07:55:23.719Z'),
('primary_currency', 'KES', 'Finance', 'Base accounting currency (Kenyan Shilling - Ksh)', '2026-10-05T07:55:23.719Z'),
('currency_symbol', 'Ksh', 'Finance', 'Rendered currency display prefix', '2026-10-05T07:55:23.719Z'),
('timezone', 'UTC', 'Localization', 'System canonical timezone (East Africa Time EAT UTC+03:00 display)', '2026-10-05T07:55:23.719Z'),
('foreign_keys_status', 'ENFORCED', 'Integrity', 'Referential integrity active on guests, rooms, bookings, and incidentals', '2026-10-05T07:55:23.719Z'),
('portability_standard', 'SQL-92 / MySQL 8.0 DDL Compliant', 'Portability', 'Certified standalone re-importability for administrators', '2026-10-05T07:55:23.719Z'),
('export_generated_at', '2026-10-05T07:55:23.719Z', 'Audit', 'Exact system snapshot timestamp', '2026-10-05T07:55:23.719Z');

-- --------------------------------------------------------
-- Table structure & data for: `rooms`
-- --------------------------------------------------------
CREATE TABLE `rooms` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `room_number` VARCHAR(10) NOT NULL,
  `room_type` ENUM('Standard','Deluxe','Executive Suite','Presidential Suite','Penthouse') NOT NULL,
  `price` DECIMAL(10,2) NOT NULL,
  `floor` INT(11) NOT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'Available',
  `maintenance_notes` TEXT DEFAULT NULL,
  `maintenance_priority` VARCHAR(20) DEFAULT NULL,
  `maintenance_updated_at` DATETIME DEFAULT NULL,
  `bed_type` VARCHAR(50) DEFAULT NULL,
  `max_guests` INT(11) DEFAULT 2,
  `amenities` TEXT DEFAULT NULL,
  `description` TEXT DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_room_number` (`room_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `rooms`
INSERT INTO `rooms` (`id`, `room_number`, `room_type`, `price`, `floor`, `status`, `maintenance_notes`, `maintenance_priority`, `bed_type`, `max_guests`, `amenities`, `description`) VALUES
(101, '101', 'Standard', 95.00, 1, 'Occupied', NULL, NULL, 'Queen Bed', 2, 'WiFi, 43" Smart TV, AC, Safe', 'Cozy standard room overlooking the courtyard gardens.'),
(102, '102', 'Standard', 95.00, 1, 'Occupied', NULL, NULL, 'Queen Bed', 2, 'WiFi, 43" Smart TV, AC, Safe', 'Cozy standard room overlooking the courtyard gardens.'),
(103, '103', 'Standard', 95.00, 1, 'Available', NULL, NULL, 'Twin Beds', 2, 'WiFi, 43" Smart TV, AC, Safe', 'Twin configuration suitable for traveling colleagues.'),
(201, '201', 'Deluxe', 165.00, 2, 'Occupied', NULL, NULL, 'King Bed', 2, 'High-speed WiFi, 55" OLED TV, Nespresso, Balcony, Minibar', 'Spacious deluxe room with private balcony and garden terrace.'),
(202, '202', 'Deluxe', 165.00, 2, 'Available', NULL, NULL, 'King Bed', 2, 'High-speed WiFi, 55" OLED TV, Nespresso, Balcony, Minibar', 'Spacious deluxe room with private balcony and garden terrace.'),
(203, '203', 'Deluxe', 175.00, 2, 'Booked', NULL, NULL, 'King Bed', 2, 'High-speed WiFi, 55" OLED TV, Nespresso, Balcony, Minibar', 'Corner deluxe suite offering panoramic sunrise light.'),
(301, '301', 'Executive Suite', 290.00, 3, 'Under Repair', 'Deep carpet stain extraction and steam sanitation.', 'High', 'California King', 3, 'Executive Lounge Access, Marble Bath, Dyson Dryer, Sommelier Bar', 'Grand executive retreat with dedicated work salon and deep soaking tub.'),
(302, '302', 'Executive Suite', 290.00, 3, 'Available', 'HVAC compressor replacement in progress. Technicians replacing refrigerant loop and digital thermostat. Final pressure testing scheduled for 18:00.', 'High', 'California King', 3, 'Executive Lounge Access, Marble Bath, Dyson Dryer, Sommelier Bar', 'Currently scheduled for HVAC air purification maintenance.'),
(401, '401', 'Presidential Suite', 540.00, 4, 'Cleaning', NULL, 'High', 'Emperor King', 4, 'Private Butler, Jacuzzi Terrace, Dining Salon for 8, Steinway Piano', 'Opulent presidential sanctuary with bespoke finishes and private terrace.'),
(501, '501', 'Penthouse', 850.00, 5, 'Occupied', NULL, NULL, 'Emperor King', 5, 'Rooftop Heated Plunge Pool, Private Elevator, Fireplace, 360° Skydeck', 'Crown jewel penthouse with private infinity dip pool and skyline panorama.');

-- --------------------------------------------------------
-- Table structure & data for: `guests`
-- --------------------------------------------------------
CREATE TABLE `guests` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) DEFAULT NULL,
  `phone` VARCHAR(30) DEFAULT NULL,
  `id_passport` VARCHAR(50) DEFAULT NULL,
  `address` TEXT DEFAULT NULL,
  `vip_tier` ENUM('Standard','Silver','Gold','Platinum') DEFAULT 'Standard',
  `notes` TEXT DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_guest_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `guests`
INSERT INTO `guests` (`id`, `full_name`, `email`, `phone`, `id_passport`, `address`, `vip_tier`, `notes`, `created_at`) VALUES
(1, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '0742610425', 'GB98273641', '14 Berkeley Square, London', 'Platinum', 'Prefers feather-free bedding and sparkling San Pellegrino in-room.', '2026-08-10 11:20:00'),
(2, 'Dr. Marcus Sterling', 'm.sterling@biogenix-research.org', '+1 (415) 892-3401', 'US67392014', '550 Montgomery St, San Francisco, CA', 'Gold', 'Attending World Bio-Tech Symposium. Early morning breakfast tray requested.', '2026-08-14 15:45:00'),
(3, 'Sophia Laurent', 'sophia@laurent-design.fr', '+33 1 42 68 55 00', 'FR84920183', '28 Rue du Faubourg Saint-Honoré, Paris', 'Silver', 'Celebrating wedding anniversary. Floral arrangement placed.', '2026-08-28 09:15:00'),
(4, 'Kenji Takahashi', 'kenji.takahashi@omni-tokyo.jp', '+81 3 5555 0192', 'JP54109283', 'Minato-ku, Tokyo, Japan', 'Standard', 'Late arrival expected at 23:00.', '2026-09-02 18:30:00'),
(5, 'Amara Okafor', 'a.okafor@africavc.com', '+234 1 234 5678', 'NG49201823', 'Victoria Island, Lagos', 'Gold', 'Requires high-speed ethernet connection for transatlantic board calls.', '2026-09-10 14:00:00'),
(6, 'Otieno ouma', 'otienoeric848@gmail.com', '0742610425', '39857133', 'Kisumu', 'Standard', 'Registered via Guest Self-Service Portal.', '2026-09-23 16:03:02');

-- --------------------------------------------------------
-- Table structure & data for: `guest_accounts`
-- --------------------------------------------------------
CREATE TABLE `guest_accounts` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `guest_id` INT(11) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_guest_email` (`email`),
  KEY `fk_accounts_guest` (`guest_id`),
  CONSTRAINT `fk_accounts_guest` FOREIGN KEY (`guest_id`) REFERENCES `guests` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `guest_accounts`
INSERT INTO `guest_accounts` (`id`, `guest_id`, `email`, `password_hash`, `created_at`) VALUES
(1, 1, 'eleanor.vance@vanceholdings.co.uk', 'password123', '2026-08-10 11:20:00'),
(2, 2, 'm.sterling@biogenix-research.org', 'password123', '2026-08-14 15:45:00'),
(3, 3, 'sophia@laurent-design.fr', 'password123', '2026-08-28 09:15:00'),
(4, 4, 'kenji.takahashi@omni-tokyo.jp', 'password123', '2026-09-02 18:30:00'),
(5, 5, 'a.okafor@africavc.com', 'password123', '2026-09-10 14:00:00'),
(6, 6, 'otienoeric848@gmail.com', 'password123', '2026-09-23 16:03:02');

-- --------------------------------------------------------
-- Table structure & data for: `bookings`
-- --------------------------------------------------------
CREATE TABLE `bookings` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `booking_code` VARCHAR(20) NOT NULL,
  `guest_id` INT(11) NOT NULL,
  `room_id` INT(11) NOT NULL,
  `check_in` DATE NOT NULL,
  `check_out` DATE NOT NULL,
  `adults` INT(11) DEFAULT 1,
  `children` INT(11) DEFAULT 0,
  `total_amount` DECIMAL(10,2) NOT NULL,
  `paid_amount` DECIMAL(10,2) DEFAULT 0.00,
  `status` VARCHAR(20) DEFAULT 'Confirmed',
  `payment_method` VARCHAR(30) DEFAULT 'Credit Card',
  `notes` TEXT DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_booking_code` (`booking_code`),
  KEY `fk_bookings_guest` (`guest_id`),
  KEY `fk_bookings_room` (`room_id`),
  CONSTRAINT `fk_bookings_guest` FOREIGN KEY (`guest_id`) REFERENCES `guests` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_bookings_room` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `bookings`
INSERT INTO `bookings` (`id`, `booking_code`, `guest_id`, `room_id`, `check_in`, `check_out`, `adults`, `children`, `total_amount`, `paid_amount`, `status`, `payment_method`, `notes`, `created_at`) VALUES
(1023, 'AURELIA-4996', 1, 301, '2026-09-29', '2026-10-01', 2, 2, 580.00, 1160.00, 'Rejected', 'Mobile Money', NULL, '2026-09-29 22:41:10'),
(1022, 'AURELIA-4364', 1, 201, '2026-09-29', '2026-10-01', 2, 0, 330.00, 660.00, 'Checked-In', 'Mobile Money', NULL, '2026-09-29 22:33:57'),
(1021, 'AURELIA-1452', 1, 101, '2026-09-29', '2026-10-01', 2, 0, 190.00, 380.00, 'Confirmed', 'Mobile Money', NULL, '2026-09-29 22:15:36'),
(1020, 'AURELIA-1698', 1, 202, '2026-09-29', '2026-10-01', 2, 0, 330.00, 660.00, 'Pending Approval', 'Mobile Money', NULL, '2026-09-29 22:05:46'),
(1019, 'AURELIA-1488', 1, 103, '2026-09-29', '2026-10-01', 2, 0, 190.00, 380.00, 'Pending Approval', 'Mobile Money', NULL, '2026-09-29 22:04:41'),
(1018, 'AURELIA-7047', 1, 101, '2026-09-25', '2026-09-28', 2, 0, 285.00, 570.00, 'Pending Approval', 'Mobile Money', NULL, '2026-09-25 19:21:37'),
(1017, 'AURELIA-6424', 1, 301, '2026-09-25', '2026-09-27', 2, 0, 580.00, 1160.00, 'Rejected', 'Mobile Money', NULL, '2026-09-25 19:19:59'),
(1016, 'AURELIA-7868', 1, 201, '2026-09-25', '2026-09-27', 2, 0, 330.00, 660.00, 'Rejected', 'Mobile Money', NULL, '2026-09-25 19:18:31'),
(1015, 'AURELIA-7391', 1, 103, '2026-09-25', '2026-09-27', 2, 0, 190.00, 380.00, 'Checked-In', 'Mobile Money', NULL, '2026-09-25 18:53:36'),
(1014, 'AURELIA-1945', 1, 102, '2026-09-25', '2026-09-27', 2, 1, 190.00, 190.00, 'Checked-In', 'Credit Card', NULL, '2026-09-25 18:44:21'),
(1013, 'AURELIA-9436', 6, 201, '2026-10-01', '2026-10-04', 2, 0, 495.00, 495.00, 'Checked-Out', 'Credit Card', 'Direct guest reservation via Self-Service Portal for Otieno ouma.', '2026-09-23 16:03:51'),
(1012, 'AURELIA-8861', 6, 201, '2026-10-01', '2026-10-04', 2, 0, 495.00, 495.00, 'Confirmed', 'Credit Card', 'Direct guest reservation via Self-Service Portal for Otieno ouma.', '2026-09-23 16:03:50'),
(1011, 'AURELIA-8045', 6, 201, '2026-10-01', '2026-10-04', 2, 0, 495.00, 495.00, 'Confirmed', 'Credit Card', 'Direct guest reservation via Self-Service Portal for Otieno ouma.', '2026-09-23 16:03:49'),
(1010, 'AURELIA-2488', 6, 201, '2026-10-01', '2026-10-04', 2, 0, 495.00, 495.00, 'Confirmed', 'Credit Card', 'Direct guest reservation via Self-Service Portal for Otieno ouma.', '2026-09-23 16:03:20'),
(1009, 'AURELIA-5826', 6, 201, '2026-10-01', '2026-10-04', 2, 0, 495.00, 495.00, 'Confirmed', 'Credit Card', 'Direct guest reservation via Self-Service Portal for Otieno ouma.', '2026-09-23 16:03:19'),
(1008, 'AURELIA-3467', 6, 201, '2026-10-01', '2026-10-04', 2, 0, 495.00, 495.00, 'Confirmed', 'Credit Card', 'Direct guest reservation via Self-Service Portal for Otieno ouma.', '2026-09-23 16:03:18'),
(1007, 'AURELIA-3442', 6, 201, '2026-10-01', '2026-10-04', 2, 0, 495.00, 495.00, 'Confirmed', 'Credit Card', 'Direct guest reservation via Self-Service Portal for Otieno ouma.', '2026-09-23 16:03:16'),
(1006, 'AURELIA-8522', 1, 101, '2026-09-23', '2026-09-26', 2, 0, 285.00, 285.00, 'Checked-In', 'Credit Card', NULL, '2026-09-23 15:32:24'),
(1001, 'AURELIA-7821', 1, 501, '2026-09-20', '2026-09-25', 2, 0, 4250.00, 4250.00, 'Checked-In', 'Credit Card', 'VIP Champagne welcome setup', '2026-09-15 10:12:00'),
(1002, 'AURELIA-7822', 2, 202, '2026-09-22', '2026-09-26', 1, 0, 660.00, 660.00, 'Checked-In', 'Direct Bill', 'Corporate rate applied', '2026-09-18 16:30:00'),
(1003, 'AURELIA-7823', 3, 102, '2026-09-21', '2026-09-24', 2, 0, 285.00, 150.00, 'Checked-In', 'Credit Card', 'Remaining balance due at checkout', '2026-09-19 12:40:00'),
(1004, 'AURELIA-7824', 4, 203, '2026-09-24', '2026-09-28', 1, 0, 700.00, 700.00, 'Confirmed', 'Credit Card', 'Airport luxury sedan pickup requested', '2026-09-21 08:15:00'),
(1005, 'AURELIA-7825', 5, 401, '2026-09-25', '2026-09-30', 2, 1, 2700.00, 1000.00, 'Confirmed', 'Bank Transfer', 'Family suite configuration with baby cot', '2026-09-22 14:50:00');

-- --------------------------------------------------------
-- Table structure & data for: `billing_items`
-- --------------------------------------------------------
CREATE TABLE `billing_items` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `booking_id` INT(11) NOT NULL,
  `description` VARCHAR(255) NOT NULL,
  `category` VARCHAR(50) NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `item_date` DATE NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_billing_booking` (`booking_id`),
  CONSTRAINT `fk_billing_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `billing_items`
INSERT INTO `billing_items` (`id`, `booking_id`, `description`, `category`, `amount`, `item_date`) VALUES
(1, 1001, 'Penthouse Suite (5 nights @ $850)', 'Room Charge', 4250.00, '2026-09-20'),
(2, 1001, 'Beluga Caviar & Dom Pérignon', 'Restaurant & Bar', 480.00, '2026-09-21'),
(3, 1001, 'Holistic Aromatherapy Spa (2 persons)', 'Spa & Wellness', 320.00, '2026-09-22'),
(4, 1002, 'Deluxe Room (4 nights @ $165)', 'Room Charge', 660.00, '2026-09-22'),
(5, 1002, 'In-Room Business Dining', 'Restaurant & Bar', 84.50, '2026-09-22'),
(6, 1003, 'Standard Room (3 nights @ $95)', 'Room Charge', 285.00, '2026-09-21'),
(7, 1003, 'Artisanal Patisserie & Espresso', 'Restaurant & Bar', 42.00, '2026-09-22'),
(8, 1006, 'Standard (3 nights @ $95.00)', 'Room Charge', 285.00, '2026-09-23'),
(9, 1007, 'Deluxe (3 nights @ $165.00)', 'Room Charge', 495.00, '2026-10-01'),
(10, 1008, 'Deluxe (3 nights @ $165.00)', 'Room Charge', 495.00, '2026-10-01'),
(11, 1009, 'Deluxe (3 nights @ $165.00)', 'Room Charge', 495.00, '2026-10-01'),
(12, 1010, 'Deluxe (3 nights @ $165.00)', 'Room Charge', 495.00, '2026-10-01'),
(13, 1011, 'Deluxe (3 nights @ $165.00)', 'Room Charge', 495.00, '2026-10-01'),
(14, 1012, 'Deluxe (3 nights @ $165.00)', 'Room Charge', 495.00, '2026-10-01'),
(15, 1013, 'Deluxe (3 nights @ $165.00)', 'Room Charge', 495.00, '2026-10-01'),
(16, 1014, 'Standard (2 nights @ $95.00)', 'Room Charge', 190.00, '2026-09-25'),
(17, 1015, 'Standard (2 nights @ Ksh 95)', 'Room Charge', 190.00, '2026-09-25'),
(18, 1015, 'Mobile Money Payment (+44 20 7946 0912) - Ref: MPESA-559886', 'Room Charge', -190.00, '2026-09-25'),
(19, 1016, 'Deluxe (2 nights @ Ksh 165)', 'Room Charge', 330.00, '2026-09-25'),
(20, 1016, 'Mobile Money Payment (+44 20 7946 0912) - Ref: MPESA-487080', 'Room Charge', -330.00, '2026-09-25'),
(21, 1017, 'Executive Suite (2 nights @ Ksh 290)', 'Room Charge', 580.00, '2026-09-25'),
(22, 1017, 'Mobile Money Payment (+254725745519) - Ref: MPESA-154686', 'Room Charge', -580.00, '2026-09-25'),
(23, 1018, 'Standard (3 nights @ Ksh 95)', 'Room Charge', 285.00, '2026-09-25'),
(24, 1018, 'Mobile Money Payment (0725745519) - Ref: MPESA-442466', 'Room Charge', -285.00, '2026-09-25'),
(25, 1019, 'Standard (2 nights @ Ksh 95)', 'Room Charge', 190.00, '2026-09-29'),
(26, 1019, 'Mobile Money Payment (+44 20 7946 0912) - Ref: MPESA-234438', 'Room Charge', -190.00, '2026-09-29'),
(27, 1020, 'Deluxe (2 nights @ Ksh 165)', 'Room Charge', 330.00, '2026-09-29'),
(28, 1020, 'Mobile Money Payment (0742610425) - Ref: MPESA-505929', 'Room Charge', -330.00, '2026-09-29'),
(29, 1021, 'Standard (2 nights @ Ksh 95)', 'Room Charge', 190.00, '2026-09-29'),
(30, 1021, 'Mobile Money Payment (0742610425) - Ref: MPESA-QHK574529', 'Room Charge', -190.00, '2026-09-29'),
(31, 1022, 'Deluxe (2 nights @ Ksh 165)', 'Room Charge', 330.00, '2026-09-29'),
(32, 1022, 'Mobile Money Payment (0742610425) - Ref: MPESA-QHK618368', 'Room Charge', -330.00, '2026-09-29'),
(33, 1023, 'Executive Suite (2 nights @ Ksh 290)', 'Room Charge', 580.00, '2026-09-29'),
(34, 1023, 'Mobile Money Payment (0742610425) - Ref: MPESA-QHK618368', 'Room Charge', -580.00, '2026-09-29');

-- --------------------------------------------------------
-- Table structure & data for: `housekeeping_tasks`
-- --------------------------------------------------------
CREATE TABLE `housekeeping_tasks` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `room_id` INT(11) NOT NULL,
  `assigned_to` VARCHAR(100) DEFAULT NULL,
  `task_status` VARCHAR(30) DEFAULT 'Pending',
  `priority` VARCHAR(20) DEFAULT 'Medium',
  `notes` TEXT DEFAULT NULL,
  `scheduled_date` DATE DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_housekeeping_room` (`room_id`),
  CONSTRAINT `fk_housekeeping_room` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `housekeeping_tasks`
INSERT INTO `housekeeping_tasks` (`id`, `room_id`, `assigned_to`, `task_status`, `priority`, `notes`, `scheduled_date`) VALUES
(1, 103, 'Maria Santos', 'Inspected', 'High', 'Deep sanitize and replenish high-thread count linens', '2026-09-23'),
(2, 302, 'Carlos Mendez', 'Completed', 'Medium', 'HVAC filter inspection alongside technical facilities', '2026-09-23'),
(3, 201, 'Elena Rostova', 'Completed', 'Low', 'Routine turn-down service and evening orchid replenishment', '2026-09-23'),
(4, 501, 'Elena Rostova', 'Completed', 'High', 'Penthouse pool check and terrace glass cleaning', '2026-09-23'),
(5, 201, 'Turnover Team', 'Completed', 'High', 'Post checkout departure turnover for Room 201', '2026-09-25'),
(6, 201, 'Turnover Team', 'Completed', 'High', 'Post checkout departure turnover for Room 201', '2026-09-25');

-- --------------------------------------------------------
-- Table structure & data for: `notifications`
-- --------------------------------------------------------
CREATE TABLE `notifications` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `recipient_name` VARCHAR(100) NOT NULL,
  `recipient_email` VARCHAR(100) DEFAULT NULL,
  `recipient_phone` VARCHAR(30) DEFAULT NULL,
  `event_type` VARCHAR(50) NOT NULL,
  `channel` VARCHAR(20) DEFAULT 'BOTH',
  `subject` VARCHAR(255) NOT NULL,
  `email_body` TEXT NOT NULL,
  `sms_body` TEXT NOT NULL,
  `status` VARCHAR(20) DEFAULT 'DELIVERED',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_notif_email` (`recipient_email`),
  KEY `idx_notif_type` (`event_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `notifications`
INSERT INTO `notifications` (`id`, `recipient_name`, `recipient_email`, `recipient_phone`, `event_type`, `channel`, `subject`, `email_body`, `sms_body`, `status`, `created_at`) VALUES
(29, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '+44 20 7946 0912', 'BOOKING_REJECTED', 'BOTH', 'Booking Notice: AURELIA-7868 - Grand Aurelia Resort & Suites', 'Dear Lady Eleanor Vance,

We regret to inform you that your reservation request AURELIA-7868 could not be confirmed at this time and has been rejected by administration.

REASON FOR REJECTION:
• Payment verification could not be matched with bank / MPESA records.

Any advance payments will be credited back via your original payment channel within 24 hours. For questions, please reach our front desk at +254 700 888 999.

Sincerely,
Executive Management Directorate
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia Resort & Suites: Notice for booking Ref: AURELIA-7868 (Room 201). Regrettably, your booking has been REJECTED. Reason: Payment verification could not be matched with bank / MPESA records.. Any payments processed will be refunded. Support: +254 700 888 999.', 'DELIVERED', '2026-09-29 22:50:23'),
(28, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '0742610425', 'BOOKING_REJECTED', 'BOTH', 'Booking Notice: AURELIA-4996 - Grand Aurelia Resort & Suites', 'Dear Lady Eleanor Vance,

We regret to inform you that your reservation request AURELIA-4996 could not be confirmed at this time and has been rejected by administration.

REASON FOR REJECTION:
• Reservation details incomplete or failed guest identification.

Any advance payments will be credited back via your original payment channel within 24 hours. For questions, please reach our front desk at +254 700 888 999.

Sincerely,
Executive Management Directorate
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia Resort & Suites: Notice for booking Ref: AURELIA-4996 (Room 301). Regrettably, your booking has been REJECTED. Reason: Reservation details incomplete or failed guest identification.. Any payments processed will be refunded. Support: +254 700 888 999.', 'DELIVERED', '2026-09-29 22:46:44'),
(27, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '+44 20 7946 0912', 'BOOKING_APPROVED', 'SMS', 'Arrival Confirmed: Room 101 Access Active', 'Dear Lady Eleanor Vance,

Welcome to Grand Aurelia Resort & Suites!

Your digital check-in for Room 101 has been processed at the arrival kiosk. Your keycard is active.

Enjoy your stay!', 'Grand Aurelia Resort: Welcome Lady Eleanor Vance! Digital Check-In completed via Arrival Scanner for Room 101. Keycard: GA-KEY-101-688. Concierge: +254 700 888 999.', 'DELIVERED', '2026-09-29 22:43:27'),
(26, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '0742610425', 'BOOKING_APPROVED', 'SMS', 'Arrival Confirmed: Room 201 Access Active', 'Dear Lady Eleanor Vance,

Welcome to Grand Aurelia Resort & Suites!

Your digital check-in for Room 201 has been processed at the arrival kiosk. Your keycard is active.

Enjoy your stay!', 'Grand Aurelia Resort: Welcome Lady Eleanor Vance! Digital Check-In completed via Arrival Scanner for Room 201. Keycard: GA-KEY-201-319. Concierge: +254 700 888 999.', 'DELIVERED', '2026-09-29 22:43:15'),
(25, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '0742610425', 'BOOKING_CREATED', 'BOTH', 'Payment Confirmed: AURELIA-4996 - Grand Aurelia Resort & Suites', 'Dear Lady Eleanor Vance,

We have received your payment of Ksh 580 for reservation AURELIA-4996.

PAYMENT DETAILS:
• Hotel: Grand Aurelia Resort & Suites
• Room: Room 301 (Executive Suite)
• Amount Paid: Ksh 580
• Days / Duration: 2 Days (2026-09-29 to 2026-10-01)
• Payment Method: M-Pesa STK Push
• Source Account / Number: 0742610425
• Transaction Reference: MPESA-QHK618368

We look forward to hosting you!

Warm regards,
Finance & Reservations
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia Resort & Suites: Payment received! Room: 301. Amount Paid: Ksh 580. Duration: 2 Days (2026-09-29 to 2026-10-01). Source: M-Pesa 0742610425. Ref: MPESA-QHK618368. Thank you!', 'DELIVERED', '2026-09-29 22:41:24'),
(24, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '0742610425', 'BOOKING_CREATED', 'BOTH', 'Reservation Confirmed: AURELIA-4996 - Grand Aurelia Resort & Suites', 'Dear Lady Eleanor Vance,

We are delighted to confirm your luxury reservation at Grand Aurelia Resort & Suites!

RESERVATION SUMMARY:
• Confirmation Code: AURELIA-4996
• Suite: Room 301 (Executive Suite)
• Check-In Date: 2026-09-29 (After 15:00)
• Check-Out Date: 2026-10-01 (By 12:00)
• Duration: 2 Days / Nights
• Guests: 2 Adults, 2 Children
• Total Rate: Ksh 580 (Paid: Ksh 580)
• Payment Method: Mobile Money
• Contact Phone: 0742610425

Our concierge desk is available 24/7. An official printable HTML Folio has been generated in your portal.

Warm regards,
Reservations Directorate
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia Resort & Suites: Booking confirmed! Room: 301. Amount Paid: Ksh 580. Duration: 2 Days (2026-09-29 to 2026-10-01). Ref: AURELIA-4996. Concierge: +254 700 888 999.', 'DELIVERED', '2026-09-29 22:41:10'),
(23, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '0742610425', 'BOOKING_CREATED', 'BOTH', 'Payment Confirmed: AURELIA-4364 - Grand Aurelia Resort & Suites', 'Dear Lady Eleanor Vance,

We have received your payment of Ksh 330 for reservation AURELIA-4364.

PAYMENT DETAILS:
• Hotel: Grand Aurelia Resort & Suites
• Room: Room 201 (Deluxe)
• Amount Paid: Ksh 330
• Days / Duration: 2 Days (2026-09-29 to 2026-10-01)
• Payment Method: M-Pesa STK Push
• Source Account / Number: 0742610425
• Transaction Reference: MPESA-QHK618368

We look forward to hosting you!

Warm regards,
Finance & Reservations
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia Resort & Suites: Payment received! Room: 201. Amount Paid: Ksh 330. Duration: 2 Days (2026-09-29 to 2026-10-01). Source: M-Pesa 0742610425. Ref: MPESA-QHK618368. Thank you!', 'DELIVERED', '2026-09-29 22:34:10'),
(22, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '0742610425', 'BOOKING_CREATED', 'BOTH', 'Reservation Confirmed: AURELIA-4364 - Grand Aurelia Resort & Suites', 'Dear Lady Eleanor Vance,

We are delighted to confirm your luxury reservation at Grand Aurelia Resort & Suites!

RESERVATION SUMMARY:
• Confirmation Code: AURELIA-4364
• Suite: Room 201 (Deluxe)
• Check-In Date: 2026-09-29 (After 15:00)
• Check-Out Date: 2026-10-01 (By 12:00)
• Duration: 2 Days / Nights
• Guests: 2 Adults, 0 Children
• Total Rate: Ksh 330 (Paid: Ksh 330)
• Payment Method: Mobile Money
• Contact Phone: 0742610425

Our concierge desk is available 24/7. An official printable HTML Folio has been generated in your portal.

Warm regards,
Reservations Directorate
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia Resort & Suites: Booking confirmed! Room: 201. Amount Paid: Ksh 330. Duration: 2 Days (2026-09-29 to 2026-10-01). Ref: AURELIA-4364. Concierge: +254 700 888 999.', 'DELIVERED', '2026-09-29 22:33:57'),
(21, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '0742610425', 'BOOKING_CREATED', 'BOTH', 'Payment Confirmed: AURELIA-1452 - Grand Aurelia Resort & Suites', 'Dear Lady Eleanor Vance,

We have received your payment of Ksh 190 for reservation AURELIA-1452.

PAYMENT DETAILS:
• Hotel: Grand Aurelia Resort & Suites
• Room: Room 101 (Standard)
• Amount Paid: Ksh 190
• Days / Duration: 2 Days (2026-09-29 to 2026-10-01)
• Payment Method: M-Pesa STK Push
• Source Account / Number: 0742610425
• Transaction Reference: MPESA-QHK574529

We look forward to hosting you!

Warm regards,
Finance & Reservations
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia Resort & Suites: Payment received! Room: 101. Amount Paid: Ksh 190. Duration: 2 Days (2026-09-29 to 2026-10-01). Source: M-Pesa 0742610425. Ref: MPESA-QHK574529. Thank you!', 'DELIVERED', '2026-09-29 22:15:59'),
(20, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '0742610425', 'BOOKING_CREATED', 'BOTH', 'Reservation Confirmed: AURELIA-1452 - Grand Aurelia Resort & Suites', 'Dear Lady Eleanor Vance,

We are delighted to confirm your luxury reservation at Grand Aurelia Resort & Suites!

RESERVATION SUMMARY:
• Confirmation Code: AURELIA-1452
• Suite: Room 101 (Standard)
• Check-In Date: 2026-09-29 (After 15:00)
• Check-Out Date: 2026-10-01 (By 12:00)
• Duration: 2 Days / Nights
• Guests: 2 Adults, 0 Children
• Total Rate: Ksh 190 (Paid: Ksh 190)
• Payment Method: Mobile Money
• Contact Phone: 0742610425

Our concierge desk is available 24/7. An official printable HTML Folio has been generated in your portal.

Warm regards,
Reservations Directorate
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia Resort & Suites: Booking confirmed! Room: 101. Amount Paid: Ksh 190. Duration: 2 Days (2026-09-29 to 2026-10-01). Ref: AURELIA-1452. Concierge: +254 700 888 999.', 'DELIVERED', '2026-09-29 22:15:36'),
(19, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '0742610425', 'BOOKING_CREATED', 'BOTH', 'Payment Confirmed: AURELIA-1698 - Grand Aurelia Resort & Suites', 'Dear Lady Eleanor Vance,

We have received your mobile payment of Ksh 330 for reservation AURELIA-1698.

PAYMENT DETAILS:
• Hotel: Grand Aurelia Resort & Suites
• Room: Room 202 (Deluxe)
• Amount Paid: Ksh 330
• Days / Duration: 2 Days (2026-09-29 to 2026-10-01)
• Transaction Reference: MPESA-505929
• Mobile Number: 0742610425

We look forward to hosting you!

Warm regards,
Finance & Reservations
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia Resort & Suites: Payment received! Room: 202. Amount Paid: Ksh 330. Duration: 2 Days (2026-09-29 to 2026-10-01). Ref: MPESA-505929. Thank you!', 'DELIVERED', '2026-09-29 22:05:54'),
(18, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '0742610425', 'BOOKING_CREATED', 'BOTH', 'Reservation Confirmed: AURELIA-1698 - Grand Aurelia Resort & Suites', 'Dear Lady Eleanor Vance,

We are delighted to confirm your luxury reservation at Grand Aurelia Resort & Suites!

RESERVATION SUMMARY:
• Confirmation Code: AURELIA-1698
• Suite: Room 202 (Deluxe)
• Check-In Date: 2026-09-29 (After 15:00)
• Check-Out Date: 2026-10-01 (By 12:00)
• Duration: 2 Days / Nights
• Guests: 2 Adults, 0 Children
• Total Rate: Ksh 330 (Paid: Ksh 330)
• Payment Method: Mobile Money
• Contact Phone: 0742610425

Our concierge desk is available 24/7. An official printable HTML Folio has been generated in your portal.

Warm regards,
Reservations Directorate
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia Resort & Suites: Booking confirmed! Room: 202. Amount Paid: Ksh 330. Duration: 2 Days (2026-09-29 to 2026-10-01). Ref: AURELIA-1698. Concierge: +254 700 888 999.', 'DELIVERED', '2026-09-29 22:05:46'),
(17, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '+44 20 7946 0912', 'BOOKING_CREATED', 'BOTH', 'Payment Confirmed: AURELIA-1488 - Grand Aurelia Resort & Suites', 'Dear Lady Eleanor Vance,

We have received your mobile payment of Ksh 190 for reservation AURELIA-1488.

PAYMENT DETAILS:
• Hotel: Grand Aurelia Resort & Suites
• Room: Room 103 (Standard)
• Amount Paid: Ksh 190
• Days / Duration: 2 Days (2026-09-29 to 2026-10-01)
• Transaction Reference: MPESA-234438
• Mobile Number: +44 20 7946 0912

We look forward to hosting you!

Warm regards,
Finance & Reservations
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia Resort & Suites: Payment received! Room: 103. Amount Paid: Ksh 190. Duration: 2 Days (2026-09-29 to 2026-10-01). Ref: MPESA-234438. Thank you!', 'DELIVERED', '2026-09-29 22:04:51'),
(16, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '+44 20 7946 0912', 'BOOKING_CREATED', 'BOTH', 'Reservation Confirmed: AURELIA-1488 - Grand Aurelia Resort & Suites', 'Dear Lady Eleanor Vance,

We are delighted to confirm your luxury reservation at Grand Aurelia Resort & Suites!

RESERVATION SUMMARY:
• Confirmation Code: AURELIA-1488
• Suite: Room 103 (Standard)
• Check-In Date: 2026-09-29 (After 15:00)
• Check-Out Date: 2026-10-01 (By 12:00)
• Duration: 2 Days / Nights
• Guests: 2 Adults, 0 Children
• Total Rate: Ksh 190 (Paid: Ksh 190)
• Payment Method: Mobile Money
• Contact Phone: +44 20 7946 0912

Our concierge desk is available 24/7. An official printable HTML Folio has been generated in your portal.

Warm regards,
Reservations Directorate
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia Resort & Suites: Booking confirmed! Room: 103. Amount Paid: Ksh 190. Duration: 2 Days (2026-09-29 to 2026-10-01). Ref: AURELIA-1488. Concierge: +254 700 888 999.', 'DELIVERED', '2026-09-29 22:04:41'),
(15, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '+44 20 7946 0912', 'BOOKING_APPROVED', 'SMS', 'Arrival Confirmed: Room 102 Access Active', 'Dear Lady Eleanor Vance,

Welcome to Grand Aurelia Resort & Suites!

Your digital check-in for Room 102 has been processed at the arrival kiosk. Your keycard is active.

Enjoy your stay!', 'Grand Aurelia Resort: Welcome Lady Eleanor Vance! Digital Check-In completed via Arrival Scanner for Room 102. Keycard: GA-KEY-102-124. Concierge: +254 700 888 999.', 'DELIVERED', '2026-09-27 21:56:55'),
(14, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '+44 20 7946 0912', 'BOOKING_APPROVED', 'SMS', 'Arrival Confirmed: Room 103 Access Active', 'Dear Lady Eleanor Vance,

Welcome to Grand Aurelia Resort & Suites!

Your digital check-in for Room 103 has been processed at the arrival kiosk. Your keycard is active.

Enjoy your stay!', 'Grand Aurelia Resort: Welcome Lady Eleanor Vance! Digital Check-In completed via Arrival Scanner for Room 103. Keycard: GA-KEY-103-512. Concierge: +254 700 888 999.', 'DELIVERED', '2026-09-27 21:53:03'),
(13, 'Otieno ouma', 'otienoeric848@gmail.com', '0742610425', 'BOOKING_APPROVED', 'BOTH', 'Booking Approved: AURELIA-8861 - Grand Aurelia Resort & Suites', 'Dear Otieno ouma,

We are pleased to inform you that your reservation AURELIA-8861 has been officially APPROVED and verified by the General Manager.

RESERVATION SUMMARY:
• Booking Ref: AURELIA-8861
• Suite: Room 201 (Deluxe)
• Duration: 3 Days (2026-10-01 to 2026-10-04)
• Total Amount: Ksh 495 (Paid: Ksh 495)
• Guest Phone: 0742610425
• Management Notes: Payment proof verified via MPESA / bank gateway. Booking officially confirmed.

We eagerly await your arrival.

Warm regards,
Arthur Pendelton | General Manager
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia Resort & Suites: Your booking Ref: AURELIA-8861 for Room 201 has been APPROVED by Management. Stay duration: 3 Days (2026-10-01 to 2026-10-04). Amount: Ksh 495. Welcome to Grand Aurelia!', 'DELIVERED', '2026-09-26 20:16:52'),
(12, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '+254725745519', 'BOOKING_REJECTED', 'BOTH', 'Booking Notice: AURELIA-6424 - Grand Aurelia Resort & Suites', 'Dear Lady Eleanor Vance,

We regret to inform you that your reservation request AURELIA-6424 could not be confirmed at this time and has been rejected by administration.

REASON FOR REJECTION:
• Payment verification could not be matched with bank / MPESA records.

Any advance payments will be credited back via your original payment channel within 24 hours. For questions, please reach our front desk at +254 700 888 999.

Sincerely,
Executive Management Directorate
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia Resort & Suites: Notice for booking Ref: AURELIA-6424 (Room 301). Regrettably, your booking has been REJECTED. Reason: Payment verification could not be matched with bank / MPESA records.. Any payments processed will be refunded. Support: +254 700 888 999.', 'DELIVERED', '2026-09-26 11:14:49'),
(11, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '0725745519', 'BOOKING_CREATED', 'BOTH', 'Payment Confirmed: AURELIA-7047 - Grand Aurelia Resort & Suites', 'Dear Lady Eleanor Vance,

We have received your mobile payment of Ksh 285 for reservation AURELIA-7047.

PAYMENT DETAILS:
• Hotel: Grand Aurelia Resort & Suites
• Room: Room 101 (Standard)
• Amount Paid: Ksh 285
• Days / Duration: 3 Days (2026-09-25 to 2026-09-28)
• Transaction Reference: MPESA-442466
• Mobile Number: 0725745519

We look forward to hosting you!

Warm regards,
Finance & Reservations
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia Resort & Suites: Payment received! Room: 101. Amount Paid: Ksh 285. Duration: 3 Days (2026-09-25 to 2026-09-28). Ref: MPESA-442466. Thank you!', 'DELIVERED', '2026-09-25 19:21:43'),
(10, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '0725745519', 'BOOKING_CREATED', 'BOTH', 'Reservation Confirmed: AURELIA-7047 - Grand Aurelia Resort & Suites', 'Dear Lady Eleanor Vance,

We are delighted to confirm your luxury reservation at Grand Aurelia Resort & Suites!

RESERVATION SUMMARY:
• Confirmation Code: AURELIA-7047
• Suite: Room 101 (Standard)
• Check-In Date: 2026-09-25 (After 15:00)
• Check-Out Date: 2026-09-28 (By 12:00)
• Duration: 3 Days / Nights
• Guests: 2 Adults, 0 Children
• Total Rate: Ksh 285 (Paid: Ksh 285)
• Payment Method: Mobile Money
• Contact Phone: 0725745519

Our concierge desk is available 24/7. An official printable HTML Folio has been generated in your portal.

Warm regards,
Reservations Directorate
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia Resort & Suites: Booking confirmed! Room: 101. Amount Paid: Ksh 285. Duration: 3 Days (2026-09-25 to 2026-09-28). Ref: AURELIA-7047. Concierge: +254 700 888 999.', 'DELIVERED', '2026-09-25 19:21:37'),
(9, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '+254725745519', 'BOOKING_CREATED', 'BOTH', 'Payment Confirmed: AURELIA-6424 - Grand Aurelia Resort & Suites', 'Dear Lady Eleanor Vance,

We have received your mobile payment of Ksh 580 for reservation AURELIA-6424.

PAYMENT DETAILS:
• Hotel: Grand Aurelia Resort & Suites
• Room: Room 301 (Executive Suite)
• Amount Paid: Ksh 580
• Days / Duration: 2 Days (2026-09-25 to 2026-09-27)
• Transaction Reference: MPESA-154686
• Mobile Number: +254725745519

We look forward to hosting you!

Warm regards,
Finance & Reservations
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia Resort & Suites: Payment received! Room: 301. Amount Paid: Ksh 580. Duration: 2 Days (2026-09-25 to 2026-09-27). Ref: MPESA-154686. Thank you!', 'DELIVERED', '2026-09-25 19:20:06'),
(8, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '+254725745519', 'BOOKING_CREATED', 'BOTH', 'Reservation Confirmed: AURELIA-6424 - Grand Aurelia Resort & Suites', 'Dear Lady Eleanor Vance,

We are delighted to confirm your luxury reservation at Grand Aurelia Resort & Suites!

RESERVATION SUMMARY:
• Confirmation Code: AURELIA-6424
• Suite: Room 301 (Executive Suite)
• Check-In Date: 2026-09-25 (After 15:00)
• Check-Out Date: 2026-09-27 (By 12:00)
• Duration: 2 Days / Nights
• Guests: 2 Adults, 0 Children
• Total Rate: Ksh 580 (Paid: Ksh 580)
• Payment Method: Mobile Money
• Contact Phone: +254725745519

Our concierge desk is available 24/7. An official printable HTML Folio has been generated in your portal.

Warm regards,
Reservations Directorate
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia Resort & Suites: Booking confirmed! Room: 301. Amount Paid: Ksh 580. Duration: 2 Days (2026-09-25 to 2026-09-27). Ref: AURELIA-6424. Concierge: +254 700 888 999.', 'DELIVERED', '2026-09-25 19:19:59'),
(7, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '+44 20 7946 0912', 'BOOKING_CREATED', 'BOTH', 'Payment Confirmed: AURELIA-7868 - Grand Aurelia Resort & Suites', 'Dear Lady Eleanor Vance,

We have received your mobile payment of Ksh 330 for reservation AURELIA-7868.

PAYMENT DETAILS:
• Hotel: Grand Aurelia Resort & Suites
• Room: Room 201 (Deluxe)
• Amount Paid: Ksh 330
• Days / Duration: 2 Days (2026-09-25 to 2026-09-27)
• Transaction Reference: MPESA-487080
• Mobile Number: +44 20 7946 0912

We look forward to hosting you!

Warm regards,
Finance & Reservations
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia Resort & Suites: Payment received! Room: 201. Amount Paid: Ksh 330. Duration: 2 Days (2026-09-25 to 2026-09-27). Ref: MPESA-487080. Thank you!', 'DELIVERED', '2026-09-25 19:18:37'),
(6, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '+44 20 7946 0912', 'BOOKING_CREATED', 'BOTH', 'Reservation Confirmed: AURELIA-7868 - Grand Aurelia Resort & Suites', 'Dear Lady Eleanor Vance,

We are delighted to confirm your luxury reservation at Grand Aurelia Resort & Suites!

RESERVATION SUMMARY:
• Confirmation Code: AURELIA-7868
• Suite: Room 201 (Deluxe)
• Check-In Date: 2026-09-25 (After 15:00)
• Check-Out Date: 2026-09-27 (By 12:00)
• Duration: 2 Days / Nights
• Guests: 2 Adults, 0 Children
• Total Rate: Ksh 330 (Paid: Ksh 330)
• Payment Method: Mobile Money
• Contact Phone: +44 20 7946 0912

Our concierge desk is available 24/7. An official printable HTML Folio has been generated in your portal.

Warm regards,
Reservations Directorate
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia Resort & Suites: Booking confirmed! Room: 201. Amount Paid: Ksh 330. Duration: 2 Days (2026-09-25 to 2026-09-27). Ref: AURELIA-7868. Concierge: +254 700 888 999.', 'DELIVERED', '2026-09-25 19:18:31'),
(5, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '+44 20 7946 0912', 'BOOKING_CREATED', 'BOTH', 'Payment Confirmed: AURELIA-7391 - Grand Aurelia Resort & Suites', 'Dear Lady Eleanor Vance,

We have received your mobile payment of Ksh 190 for reservation AURELIA-7391.

PAYMENT DETAILS:
• Hotel: Grand Aurelia Resort & Suites
• Room: Room 103 (Standard)
• Amount Paid: Ksh 190
• Days / Duration: 2 Days (2026-09-25 to 2026-09-27)
• Transaction Reference: MPESA-559886
• Mobile Number: +44 20 7946 0912

We look forward to hosting you!

Warm regards,
Finance & Reservations
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia Resort & Suites: Payment received! Room: 103. Amount Paid: Ksh 190. Duration: 2 Days (2026-09-25 to 2026-09-27). Ref: MPESA-559886. Thank you!', 'DELIVERED', '2026-09-25 18:54:05'),
(4, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '+44 20 7946 0912', 'BOOKING_CREATED', 'BOTH', 'Reservation Confirmed: AURELIA-7391 - Grand Aurelia Resort & Suites', 'Dear Lady Eleanor Vance,

We are delighted to confirm your luxury reservation at Grand Aurelia Resort & Suites!

RESERVATION SUMMARY:
• Confirmation Code: AURELIA-7391
• Suite: Room 103 (Standard)
• Check-In Date: 2026-09-25 (After 15:00)
• Check-Out Date: 2026-09-27 (By 12:00)
• Duration: 2 Days / Nights
• Guests: 2 Adults, 0 Children
• Total Rate: Ksh 190 (Paid: Ksh 190)
• Payment Method: Mobile Money
• Contact Phone: +44 20 7946 0912

Our concierge desk is available 24/7. An official printable HTML Folio has been generated in your portal.

Warm regards,
Reservations Directorate
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia Resort & Suites: Booking confirmed! Room: 103. Amount Paid: Ksh 190. Duration: 2 Days (2026-09-25 to 2026-09-27). Ref: AURELIA-7391. Concierge: +254 700 888 999.', 'DELIVERED', '2026-09-25 18:53:36'),
(3, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '+44 20 7946 0912', 'BOOKING_CREATED', 'BOTH', 'Reservation Confirmed: AURELIA-1945 - Grand Aurelia Resort & Suites', 'Dear Lady Eleanor Vance,

We are delighted to confirm your luxury reservation at Grand Aurelia Resort & Suites!

RESERVATION SUMMARY:
• Confirmation Code: AURELIA-1945
• Suite: Room 102 (Standard)
• Check-In Date: 2026-09-25 (After 15:00)
• Check-Out Date: 2026-09-27 (By 12:00)
• Guests: 2 Adults, 1 Children
• Total Rate: Ksh 190 (Paid: Ksh 190)
• Payment Method: Credit Card

Our concierge desk is available 24/7. An official printable HTML Folio has been generated in your portal.

Warm regards,
Reservations Directorate
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia: Reservation Confirmed! Code: AURELIA-1945. Room 102 (Standard). Check-in: 2026-09-25. Total: Ksh 190. Concierge: +254 700 888 999.', 'DELIVERED', '2026-09-25 18:44:21'),
(1, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '+44 20 7946 0912', 'ACCOUNT_CREATED', 'BOTH', 'Welcome to Grand Aurelia Resort & Suites - Account Activated', 'Dear Lady Eleanor Vance,

Welcome to Grand Aurelia Luxury Resort & Suites!

Your online guest portal account is now active:
• Registered Email: eleanor.vance@vanceholdings.co.uk
• Loyalty Tier: Platinum VIP
• Member ID: GA-0001

You can access your reservation folios, schedule concierge requests, and enjoy preferential bookings.

Warm regards,
Front Office Team
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia Resort: Welcome Lady Eleanor Vance! Your guest portal account is active (Member ID: GA-0001). Access your Platinum VIP reservations & folios online.', 'DELIVERED', '2026-08-10 11:20:00'),
(2, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '+44 20 7946 0912', 'BOOKING_CREATED', 'BOTH', 'Reservation Confirmed: AURELIA-7821 - Grand Aurelia Resort & Suites', 'Dear Lady Eleanor Vance,

We are delighted to confirm your upcoming stay at Grand Aurelia Resort & Suites.

RESERVATION DETAILS:
• Confirmation Code: AURELIA-7821
• Suite: Room 501 (Penthouse)
• Stay: 2026-09-20 to 2026-09-25 (5 nights)
• Total Amount: Ksh 4,250 (Settled in full)
• VIP Inclusions: Rooftop heated pool, sommelier bar & 24/7 butler service.

Warm regards,
Reservations Directorate
Grand Aurelia Luxury Resort & Suites', 'Grand Aurelia: Reservation Confirmed! Code: AURELIA-7821. Penthouse (Room 501). Check-in: 2026-09-20. Total: Ksh 4,250. Concierge: +254 700 888 999.', 'DELIVERED', '2026-09-15 10:12:00');

-- --------------------------------------------------------
-- Table structure & data for: `admin_notification_alerts`
-- --------------------------------------------------------
CREATE TABLE `admin_notification_alerts` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `alert_type` VARCHAR(50) NOT NULL,
  `channel` VARCHAR(20) DEFAULT 'BOTH',
  `title` VARCHAR(255) NOT NULL,
  `sms_content` TEXT NOT NULL,
  `email_content` TEXT NOT NULL,
  `recipient` VARCHAR(100) DEFAULT 'General Manager',
  `status` ENUM('UNREAD','READ') DEFAULT 'UNREAD',
  `priority` ENUM('CRITICAL','HIGH','NORMAL') DEFAULT 'HIGH',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_alert_status` (`status`),
  KEY `idx_alert_priority` (`priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `admin_notification_alerts`
INSERT INTO `admin_notification_alerts` (`id`, `alert_type`, `channel`, `title`, `sms_content`, `email_content`, `recipient`, `status`, `priority`, `created_at`) VALUES
(16, 'BOOKING_REJECTED', 'BOTH', 'Reservation Rejected: AURELIA-7868', '[ADMIN AUDIT] Reservation AURELIA-7868 rejected by GM. Reason: Payment verification could not be matched with bank / MPESA records.. Rejection SMS sent to +44 20 7946 0912. Room 201 released to Available.', 'RESERVATION REJECTION AUDIT

Booking AURELIA-7868 was rejected.
Reason: Payment verification could not be matched with bank / MPESA records.
Room 201 inventory restored.
Guest: Lady Eleanor Vance (+44 20 7946 0912)', 'GM Direct Dispatch (+254 700 888 000) & admin@grandaurelia.com', 'UNREAD', 'HIGH', '2026-09-29 22:50:23'),
(15, 'BOOKING_REJECTED', 'BOTH', 'Reservation Rejected: AURELIA-4996', '[ADMIN AUDIT] Reservation AURELIA-4996 rejected by GM. Reason: Reservation details incomplete or failed guest identification.. Rejection SMS sent to 0742610425. Room 301 released to Available.', 'RESERVATION REJECTION AUDIT

Booking AURELIA-4996 was rejected.
Reason: Reservation details incomplete or failed guest identification.
Room 301 inventory restored.
Guest: Lady Eleanor Vance (0742610425)', 'GM Direct Dispatch (+254 700 888 000) & admin@grandaurelia.com', 'UNREAD', 'HIGH', '2026-09-29 22:46:44'),
(14, 'PAYMENT_RECEIVED', 'BOTH', 'Payment Received: Ksh 580 for Booking AURELIA-4996', '[FINANCE & GM ALERT] M-Pesa STK Confirmed: Ksh 580 transferred from 0742610425 for Booking AURELIA-4996 (Room 301). Guest: Lady Eleanor Vance. TxRef: MPESA-QHK618368.', 'FINANCE REVENUE NOTIFICATION

Booking: AURELIA-4996
Guest: Lady Eleanor Vance
Room: 301
Amount: Ksh 580
Method: Mobile Money (M-Pesa STK Push)
Source: 0742610425
Transaction ID: MPESA-QHK618368
Updated Balance Paid: Ksh 1,160', 'GM Direct Dispatch (+254 700 888 000) & admin@grandaurelia.com', 'UNREAD', 'MEDIUM', '2026-09-29 22:41:24'),
(13, 'NEW_BOOKING', 'BOTH', 'Incoming Reservation: AURELIA-4996 - Room 301', '[ADMIN ALERT] New reservation AURELIA-4996 for Room 301 (Executive Suite). Guest: Lady Eleanor Vance (0742610425). Stay: 2026-09-29 to 2026-10-01 (2 nights). Total: Ksh 580 (Paid: Ksh 580 via Mobile Money). Review in Admin Approvals.', 'ADMINISTRATIVE BOOKING INTAKE ALERT

Ref: AURELIA-4996
Room: Room 301 (Executive Suite)
Guest: Lady Eleanor Vance (0742610425, eleanor.vance@vanceholdings.co.uk)
Dates: 2026-09-29 to 2026-10-01 (2 Nights)
Payment: Ksh 580 / Ksh 580 via Mobile Money
Status: Pending

Action: Verify payment proof and approve reservation in GM Approvals portal.', 'GM Direct Dispatch (+254 700 888 000) & admin@grandaurelia.com', 'UNREAD', 'MEDIUM', '2026-09-29 22:41:10'),
(12, 'PAYMENT_RECEIVED', 'BOTH', 'Payment Received: Ksh 330 for Booking AURELIA-4364', '[FINANCE & GM ALERT] M-Pesa STK Confirmed: Ksh 330 transferred from 0742610425 for Booking AURELIA-4364 (Room 201). Guest: Lady Eleanor Vance. TxRef: MPESA-QHK618368.', 'FINANCE REVENUE NOTIFICATION

Booking: AURELIA-4364
Guest: Lady Eleanor Vance
Room: 201
Amount: Ksh 330
Method: Mobile Money (M-Pesa STK Push)
Source: 0742610425
Transaction ID: MPESA-QHK618368
Updated Balance Paid: Ksh 660', 'GM Direct Dispatch (+254 700 888 000) & admin@grandaurelia.com', 'UNREAD', 'MEDIUM', '2026-09-29 22:34:10'),
(11, 'NEW_BOOKING', 'BOTH', 'Incoming Reservation: AURELIA-4364 - Room 201', '[ADMIN ALERT] New reservation AURELIA-4364 for Room 201 (Deluxe). Guest: Lady Eleanor Vance (0742610425). Stay: 2026-09-29 to 2026-10-01 (2 nights). Total: Ksh 330 (Paid: Ksh 330 via Mobile Money). Review in Admin Approvals.', 'ADMINISTRATIVE BOOKING INTAKE ALERT

Ref: AURELIA-4364
Room: Room 201 (Deluxe)
Guest: Lady Eleanor Vance (0742610425, eleanor.vance@vanceholdings.co.uk)
Dates: 2026-09-29 to 2026-10-01 (2 Nights)
Payment: Ksh 330 / Ksh 330 via Mobile Money
Status: Pending

Action: Verify payment proof and approve reservation in GM Approvals portal.', 'GM Direct Dispatch (+254 700 888 000) & admin@grandaurelia.com', 'UNREAD', 'MEDIUM', '2026-09-29 22:33:57'),
(10, 'PAYMENT_RECEIVED', 'BOTH', 'Payment Received: Ksh 190 for Booking AURELIA-1452', '[FINANCE & GM ALERT] M-Pesa STK Confirmed: Ksh 190 transferred from 0742610425 for Booking AURELIA-1452 (Room 101). Guest: Lady Eleanor Vance. TxRef: MPESA-QHK574529.', 'FINANCE REVENUE NOTIFICATION

Booking: AURELIA-1452
Guest: Lady Eleanor Vance
Room: 101
Amount: Ksh 190
Method: Mobile Money (M-Pesa STK Push)
Source: 0742610425
Transaction ID: MPESA-QHK574529
Updated Balance Paid: Ksh 380', 'GM Direct Dispatch (+254 700 888 000) & admin@grandaurelia.com', 'UNREAD', 'MEDIUM', '2026-09-29 22:15:59'),
(9, 'NEW_BOOKING', 'BOTH', 'Incoming Reservation: AURELIA-1452 - Room 101', '[ADMIN ALERT] New reservation AURELIA-1452 for Room 101 (Standard). Guest: Lady Eleanor Vance (0742610425). Stay: 2026-09-29 to 2026-10-01 (2 nights). Total: Ksh 190 (Paid: Ksh 190 via Mobile Money). Review in Admin Approvals.', 'ADMINISTRATIVE BOOKING INTAKE ALERT

Ref: AURELIA-1452
Room: Room 101 (Standard)
Guest: Lady Eleanor Vance (0742610425, eleanor.vance@vanceholdings.co.uk)
Dates: 2026-09-29 to 2026-10-01 (2 Nights)
Payment: Ksh 190 / Ksh 190 via Mobile Money
Status: Pending

Action: Verify payment proof and approve reservation in GM Approvals portal.', 'GM Direct Dispatch (+254 700 888 000) & admin@grandaurelia.com', 'UNREAD', 'MEDIUM', '2026-09-29 22:15:36'),
(8, 'PAYMENT_RECEIVED', 'BOTH', 'Payment Received: Ksh 330 for Booking AURELIA-1698', '[FINANCE & GM ALERT] Mobile Money STK Confirmed: Ksh 330 received for Booking AURELIA-1698 (Room 202). Guest: Lady Eleanor Vance (0742610425). TxRef: MPESA-505929.', 'FINANCE REVENUE NOTIFICATION

Booking: AURELIA-1698
Guest: Lady Eleanor Vance (0742610425)
Room: 202
Amount: Ksh 330
Method: Mobile Money (STK Push)
Transaction ID: MPESA-505929
Updated Balance Paid: Ksh 660', 'GM Direct Dispatch (+254 700 888 000) & admin@grandaurelia.com', 'UNREAD', 'MEDIUM', '2026-09-29 22:05:54'),
(7, 'NEW_BOOKING', 'BOTH', 'Incoming Reservation: AURELIA-1698 - Room 202', '[ADMIN ALERT] New reservation AURELIA-1698 for Room 202 (Deluxe). Guest: Lady Eleanor Vance (0742610425). Stay: 2026-09-29 to 2026-10-01 (2 nights). Total: Ksh 330 (Paid: Ksh 330 via Mobile Money). Review in Admin Approvals.', 'ADMINISTRATIVE BOOKING INTAKE ALERT

Ref: AURELIA-1698
Room: Room 202 (Deluxe)
Guest: Lady Eleanor Vance (0742610425, eleanor.vance@vanceholdings.co.uk)
Dates: 2026-09-29 to 2026-10-01 (2 Nights)
Payment: Ksh 330 / Ksh 330 via Mobile Money
Status: Pending

Action: Verify payment proof and approve reservation in GM Approvals portal.', 'GM Direct Dispatch (+254 700 888 000) & admin@grandaurelia.com', 'UNREAD', 'MEDIUM', '2026-09-29 22:05:46'),
(6, 'PAYMENT_RECEIVED', 'BOTH', 'Payment Received: Ksh 190 for Booking AURELIA-1488', '[FINANCE & GM ALERT] Mobile Money STK Confirmed: Ksh 190 received for Booking AURELIA-1488 (Room 103). Guest: Lady Eleanor Vance (+44 20 7946 0912). TxRef: MPESA-234438.', 'FINANCE REVENUE NOTIFICATION

Booking: AURELIA-1488
Guest: Lady Eleanor Vance (+44 20 7946 0912)
Room: 103
Amount: Ksh 190
Method: Mobile Money (STK Push)
Transaction ID: MPESA-234438
Updated Balance Paid: Ksh 380', 'GM Direct Dispatch (+254 700 888 000) & admin@grandaurelia.com', 'UNREAD', 'MEDIUM', '2026-09-29 22:04:51'),
(5, 'NEW_BOOKING', 'BOTH', 'Incoming Reservation: AURELIA-1488 - Room 103', '[ADMIN ALERT] New reservation AURELIA-1488 for Room 103 (Standard). Guest: Lady Eleanor Vance (+44 20 7946 0912). Stay: 2026-09-29 to 2026-10-01 (2 nights). Total: Ksh 190 (Paid: Ksh 190 via Mobile Money). Review in Admin Approvals.', 'ADMINISTRATIVE BOOKING INTAKE ALERT

Ref: AURELIA-1488
Room: Room 103 (Standard)
Guest: Lady Eleanor Vance (+44 20 7946 0912, eleanor.vance@vanceholdings.co.uk)
Dates: 2026-09-29 to 2026-10-01 (2 Nights)
Payment: Ksh 190 / Ksh 190 via Mobile Money
Status: Pending

Action: Verify payment proof and approve reservation in GM Approvals portal.', 'GM Direct Dispatch (+254 700 888 000) & admin@grandaurelia.com', 'UNREAD', 'MEDIUM', '2026-09-29 22:04:41'),
(4, 'BOOKING_APPROVED', 'SMS', 'GM Verified & Approved: AURELIA-8861', '[ADMIN AUDIT] GM Arthur Pendelton approved reservation AURELIA-8861 (Room 201). Confirmation SMS dispatched to guest 0742610425.', 'EXECUTIVE APPROVAL AUDIT LOG

Booking AURELIA-8861 has been approved by General Manager.
Notes: Payment proof verified via MPESA / bank gateway. Booking officially confirmed.
Guest: Otieno ouma (0742610425)
Timestamp: 2026-09-26 20:16:52', 'GM Direct Dispatch (+254 700 888 000) & admin@grandaurelia.com', 'UNREAD', 'MEDIUM', '2026-09-26 20:16:52'),
(1, 'VERIFICATION_REQUIRED', 'BOTH', 'New Reservation Alert: AURELIA-7825 Requires GM Approval', '[ADMIN INCOMING ALERT] New Reservation Ref: AURELIA-7825 for Room 401 (Executive Family Suite). Guest: Dr. Aris Thorne (+254 710 234 567). Rate: Ksh 2,700 (Advance Paid: Ksh 1,000 via Bank Transfer). Status: Pending GM Verification & Proof.', 'URGENT ADMINISTRATIVE DISPATCH - RESERVATIONS DESK

To: Arthur Pendelton (General Manager) <gm@grandaurelia.com>
Cc: Front Office Supervisor <reception@grandaurelia.com>

RE: New Reservation Request AURELIA-7825 [ACTION REQUIRED]

Guest Particulars:
• Name: Dr. Aris Thorne
• Mobile Phone: +254 710 234 567
• Suite Requested: Room 401 (Executive Family Suite, 4th Floor)
• Stay Period: 2026-09-25 to 2026-09-30 (5 Nights)
• Occupants: 2 Adults, 1 Child (Baby cot requested)
• Financial Summary: Total Ksh 2,700.00 | Advance Paid: Ksh 1,000.00 via Bank Transfer

Administrative Next Steps:
1. Verify incoming bank transfer receipt against bank ledger.
2. Review booking in Admin Approvals portal to Prove or Reject.', 'GM Direct Dispatch (+254 700 888 000) & admin@grandaurelia.com', 'UNREAD', 'HIGH', '2026-09-22 14:52:10'),
(2, 'PAYMENT_RECEIVED', 'SMS', 'STK Mobile Money Payment Alert: Ksh 1,000 Received', '[FINANCE & GM ALERT] MPESA STK Gateway: Ksh 1,000.00 received from +254 710 234 567 for Booking AURELIA-7825 (Room 401). TxRef: MPESA-918234. Account balance updated.', 'AUTOMATED PAYMENT CONFIRMATION - FINANCE DIRECTORATE

Payment Reference: MPESA-918234
Booking Code: AURELIA-7825
Guest: Dr. Aris Thorne (+254 710 234 567)
Amount: Ksh 1,000.00
Channel: Mobile Money STK Push
Timestamp: 2026-09-22 14:51:30', 'Finance & GM Dispatch (+254 700 888 000)', 'READ', 'MEDIUM', '2026-09-22 14:51:30'),
(3, 'NEW_BOOKING', 'BOTH', 'VIP Penthouse Booking Confirmed: AURELIA-7821', '[ADMIN DISPATCH] High-Value Booking Confirmed: AURELIA-7821 for Room 501 (Penthouse). VIP Guest: Lady Eleanor Vance (+44 20 7946 0912). Total: Ksh 4,250.00 Settled. Butler service alerted.', 'VIP ARRIVAL ADVISORY - EXECUTIVE MANAGEMENT

Guest: Lady Eleanor Vance (Platinum VIP)
Reservation Code: AURELIA-7821
Assigned: Room 501 (Imperial Penthouse)
Duration: 2026-09-20 to 2026-09-25
Total Folio: Ksh 4,250.00 (Settled)
Inclusions: Butler concierge, private spa access, rooftop pool.', 'Executive Directorate & GM (+254 700 888 000)', 'READ', 'HIGH', '2026-09-15 10:15:00');

-- --------------------------------------------------------
-- Table structure & data for: `guest_feedbacks`
-- --------------------------------------------------------
CREATE TABLE `guest_feedbacks` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `booking_id` INT(11) NOT NULL,
  `booking_code` VARCHAR(20) NOT NULL,
  `guest_id` INT(11) NOT NULL,
  `guest_name` VARCHAR(100) NOT NULL,
  `guest_email` VARCHAR(100) NOT NULL,
  `room_number` VARCHAR(10) NOT NULL,
  `rating` TINYINT(1) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `comment` TEXT NOT NULL,
  `sentiment` ENUM('positive','neutral','constructive') DEFAULT 'positive',
  `categories` TEXT DEFAULT NULL,
  `management_response` TEXT DEFAULT NULL,
  `responder_name` VARCHAR(100) DEFAULT NULL,
  `management_responded_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_feedback_booking` (`booking_id`),
  KEY `idx_feedback_rating` (`rating`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `guest_feedbacks`
INSERT INTO `guest_feedbacks` (`id`, `booking_id`, `booking_code`, `guest_id`, `guest_name`, `guest_email`, `room_number`, `rating`, `title`, `comment`, `sentiment`, `categories`, `management_response`, `responder_name`, `created_at`) VALUES
(1, 1006, 'AURELIA-7710', 1, 'Lady Eleanor Vance', 'eleanor.vance@vanceholdings.co.uk', '501', 5, 'An Unsurpassed Penthouse Experience in Nairobi', 'The heated rooftop plunge pool and the bespoke private elevator made our diplomatic delegation stay completely frictionless. Housekeeping turndown with fresh French roses was an exquisite touch. Concierge team arranged flawless armored VIP airport transfers.', 'positive', '["Room Comfort","Staff & Service","Cleanliness"]', 'Thank you Lady Eleanor. It was our highest honor hosting your delegation, and our concierge team is thrilled your transfer and private skydeck were exceptional.', 'Aurelius Vance (General Manager)', '2026-05-18 09:14:00'),
(2, 1007, 'AURELIA-7735', 2, 'Dr. Marcus Sterling', 'm.sterling@biogenix-research.org', '301', 5, 'Sublime Quietude & Stellar Executive Work Salon', 'The executive lounge and marble soaking tub were immaculate after grueling symposium sessions. Dedicated fiber optic connection delivered over 900 Mbps for transatlantic scientific data transfers without a hitch.', 'positive', '["Cleanliness","Room Comfort","Business Amenities"]', 'Delighted to hear the suite provided the quietude and high-speed infrastructure needed for your research preparations, Dr. Sterling.', 'Julian Hayes (Front Desk Manager)', '2026-06-14 14:30:00'),
(3, 1008, 'AURELIA-7762', 3, 'Sophia Laurent', 'sophia@laurent-design.fr', '201', 5, 'Exquisite Architecture & Delightful Garden Balcony', 'The private balcony overlooking the botanical courtyard at dawn was pure tranquility. Artisanal patisserie and hot Nespresso were delivered promptly for our anniversary breakfast.', 'positive', '["Dining","Room Comfort","Staff & Service"]', 'Joyeux anniversaire once again Ms. Laurent! We are overjoyed that our garden suites and patisserie made your celebration memorable.', 'Elena Rostova (Guest Relations)', '2026-07-10 10:15:00'),
(4, 1009, 'AURELIA-7788', 4, 'Kenji Takahashi', 'kenji.takahashi@omni-tokyo.jp', '401', 4, 'World-Class Presidential Suite & Steinway, Busy Breakfast Buffet', 'The Presidential Suite is marvelous with its handcrafted woodwork and Steinway piano. Private butler service was discrete and courteous. The only minor friction was a busy breakfast buffet rush on Sunday morning, though terrace seating quickly accommodated us.', 'constructive', '["Room Comfort","Dining","Staff & Service"]', 'Arigato Mr. Takahashi. We deeply value your insight regarding Sunday peak hours. We have since introduced dedicated private in-suite breakfast service for Presidential guests.', 'Aurelius Vance (General Manager)', '2026-07-29 17:05:00'),
(5, 1010, 'AURELIA-7801', 5, 'Amara Okafor', 'a.okafor@africavc.com', '501', 5, 'Seamless Mobile Payment & Exemplary Executive Hospitality', 'Instant M-Pesa settlement on checkout was remarkably convenient. The private dining salon hosted 8 of our VC managing partners for dinner with Michelin-level culinary execution.', 'positive', '["Dining","Staff & Service","Cleanliness"]', 'Warmest thanks Ms. Okafor. Our culinary team under Chef Laurent was thrilled to cater your investment summit.', 'Julian Hayes (Front Desk Manager)', '2026-08-12 11:45:00');

-- --------------------------------------------------------
-- Table structure & audit records for: `sql_audit_logs`
-- --------------------------------------------------------
CREATE TABLE `sql_audit_logs` (
  `id` VARCHAR(50) NOT NULL,
  `timestamp` VARCHAR(50) NOT NULL,
  `query` TEXT NOT NULL,
  `status` ENUM('SUCCESS','ERROR') NOT NULL DEFAULT 'SUCCESS',
  `execution_time_ms` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `rows_affected` INT(11) NOT NULL DEFAULT 0,
  `source` ENUM('UI_ACTION','CONSOLE') NOT NULL DEFAULT 'UI_ACTION',
  PRIMARY KEY (`id`),
  KEY `idx_log_timestamp` (`timestamp`),
  KEY `idx_log_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping audit query logs
INSERT INTO `sql_audit_logs` (`id`, `timestamp`, `query`, `status`, `execution_time_ms`, `rows_affected`, `source`) VALUES
('zhhcz51', '10:53:58', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-07''
      AND b.check_out > ''2026-10-05''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.10, 9, 'UI_ACTION'),
('gfawojw', '10:53:58', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-07''
      AND b.check_out > ''2026-10-05''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.20, 9, 'UI_ACTION'),
('m3zw3xu', '10:40:37', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-07''
      AND b.check_out > ''2026-10-05''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.00, 9, 'UI_ACTION'),
('yqmcnw5', '10:40:37', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-07''
      AND b.check_out > ''2026-10-05''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.20, 9, 'UI_ACTION'),
('3p3059l', '10:37:15', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-07''
      AND b.check_out > ''2026-10-05''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.10, 9, 'UI_ACTION'),
('b6dt5ae', '10:37:15', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-07''
      AND b.check_out > ''2026-10-05''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.20, 9, 'UI_ACTION'),
('956j19t', '09:22:24', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-07''
      AND b.check_out > ''2026-10-05''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.10, 9, 'UI_ACTION'),
('9uyx99b', '09:22:24', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-07''
      AND b.check_out > ''2026-10-05''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.30, 9, 'UI_ACTION'),
('ndwu3cv', '19:29:21', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-02''
      AND b.check_out > ''2026-09-30''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.00, 5, 'UI_ACTION'),
('uqichns', '19:29:21', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-02''
      AND b.check_out > ''2026-09-30''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.10, 5, 'UI_ACTION'),
('xjmwq42', '19:29:18', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-02''
      AND b.check_out > ''2026-09-30''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.00, 5, 'UI_ACTION'),
('9ax5f3j', '19:29:18', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-02''
      AND b.check_out > ''2026-09-30''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.30, 5, 'UI_ACTION'),
('14l7u9o', '19:29:12', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-02''
      AND b.check_out > ''2026-09-30''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.10, 5, 'UI_ACTION'),
('jpuw9dl', '19:29:11', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-02''
      AND b.check_out > ''2026-09-30''
  )
ORDER BY r.price ASC;', 'SUCCESS', 1.50, 5, 'UI_ACTION'),
('hxmowdp', '19:24:27', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-02''
      AND b.check_out > ''2026-09-30''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.10, 5, 'UI_ACTION'),
('m3r0p66', '19:24:27', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-02''
      AND b.check_out > ''2026-09-30''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.30, 5, 'UI_ACTION'),
('ycqh1yz', '19:22:47', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-02''
      AND b.check_out > ''2026-09-30''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.30, 5, 'UI_ACTION'),
('kv7ixi0', '19:22:47', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-02''
      AND b.check_out > ''2026-09-30''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.50, 5, 'UI_ACTION'),
('51b78bj', '19:21:06', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-02''
      AND b.check_out > ''2026-09-30''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.20, 5, 'UI_ACTION'),
('s2a58n5', '19:21:05', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-02''
      AND b.check_out > ''2026-09-30''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.30, 5, 'UI_ACTION'),
('r7vzerh', '09:14:48', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-02''
      AND b.check_out > ''2026-09-30''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.10, 5, 'UI_ACTION'),
('ijkt50c', '09:14:48', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-02''
      AND b.check_out > ''2026-09-30''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.20, 5, 'UI_ACTION'),
('4ewb34n', '01:57:18', 'UPDATE housekeeping_tasks SET task_status = ''Completed'' WHERE id = 6;', 'SUCCESS', 0.00, 1, 'UI_ACTION'),
('xb4mak3', '01:57:15', 'UPDATE housekeeping_tasks SET task_status = ''Completed'' WHERE id = 5;', 'SUCCESS', 0.00, 1, 'UI_ACTION'),
('063gcn0', '01:57:12', 'UPDATE housekeeping_tasks SET task_status = ''Completed'' WHERE id = 2;
UPDATE rooms SET status = ''Available'' WHERE id = 302;', 'SUCCESS', 0.10, 2, 'UI_ACTION'),
('8ixt13k', '01:56:49', 'UPDATE housekeeping_tasks SET task_status = ''In Progress'' WHERE id = 6;', 'SUCCESS', 0.00, 1, 'UI_ACTION'),
('kv3j4t0', '01:56:45', 'UPDATE housekeeping_tasks SET task_status = ''In Progress'' WHERE id = 5;', 'SUCCESS', 0.10, 1, 'UI_ACTION'),
('72p9ogd', '01:56:37', 'UPDATE housekeeping_tasks SET task_status = ''In Progress'' WHERE id = 2;', 'SUCCESS', 0.00, 1, 'UI_ACTION'),
('sl8chqo', '01:56:31', 'UPDATE housekeeping_tasks SET task_status = ''Inspected'' WHERE id = 1;', 'SUCCESS', 0.00, 1, 'UI_ACTION'),
('08p6heo', '01:56:08', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-01''
      AND b.check_out > ''2026-09-29''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.20, 4, 'UI_ACTION'),
('srt0cf8', '01:56:07', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-01''
      AND b.check_out > ''2026-09-29''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.20, 4, 'UI_ACTION'),
('kr8wi17', '01:56:05', 'UPDATE rooms SET status = ''Available'' WHERE id = 202;', 'SUCCESS', 0.00, 1, 'UI_ACTION'),
('bcmo73s', '01:55:58', 'UPDATE rooms SET status = ''Available'' WHERE id = 103;', 'SUCCESS', 0.10, 1, 'UI_ACTION'),
('30fdci2', '01:55:09', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-01''
      AND b.check_out > ''2026-09-29''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.00, 4, 'UI_ACTION'),
('fa4xa5b', '01:55:09', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-01''
      AND b.check_out > ''2026-09-29''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.10, 4, 'UI_ACTION'),
('u6nn3i2', '01:54:30', 'UPDATE rooms SET status = ''Cleaning'', maintenance_notes = NULL, maintenance_priority = ''High'', maintenance_updated_at = ''2026-09-29 22:54'' WHERE id = 401;', 'SUCCESS', 0.20, 1, 'UI_ACTION'),
('hiurksl', '01:53:54', 'UPDATE rooms SET status = ''Cleaning'' WHERE id = 302;', 'SUCCESS', 0.00, 1, 'UI_ACTION'),
('mqzkj99', '01:53:52', 'UPDATE rooms SET status = ''Maintenance'' WHERE id = 302;', 'SUCCESS', 0.20, 1, 'UI_ACTION'),
('rqdsafh', '01:53:35', 'UPDATE rooms SET status = ''Under Repair'', maintenance_notes = ''Deep carpet stain extraction and steam sanitation.'', maintenance_priority = ''High'', maintenance_updated_at = ''2026-09-29 22:53'' WHERE id = 301;', 'SUCCESS', 0.30, 1, 'UI_ACTION'),
('pf1kqem', '01:52:39', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-01''
      AND b.check_out > ''2026-09-29''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.10, 3, 'UI_ACTION'),
('md512z6', '01:52:39', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-01''
      AND b.check_out > ''2026-09-29''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.10, 3, 'UI_ACTION'),
('x84p0p1', '01:52:33', '/* CENTRAL SYSTEM DATA EXPORT: Successfully generated & downloaded hotel_db_export.sql (109.6 KB, 11 relational tables + logs + schema metadata) */', 'SUCCESS', 0.60, 11, 'UI_ACTION'),
('vba2e1w', '01:50:25', '/* CENTRAL SYSTEM DATA EXPORT: Successfully generated & downloaded hotel_db_export.sql (109.4 KB, 11 relational tables + logs + schema metadata) */', 'SUCCESS', 0.60, 11, 'UI_ACTION'),
('4kiedqh', '01:50:23', 'INSERT INTO admin_notification_alerts (id, alert_type, channel, title, sms_content, email_content, recipient, status, priority, created_at)
VALUES (16, ''BOOKING_REJECTED'', ''BOTH'', ''Reservation Rejected: AURELIA-7868'', ''[ADMIN AUDIT] Reservation AURELIA-7868 rejected by GM. Reason: Payment verification could not be matched with bank / MPESA records.. Rejection SMS sent to +44 20 7946 0912. Room 201 released to Available.'', ''RESERVATION REJECTION AUDIT

Booking AURELIA-7868 was rejected.
Reason: Payment verification could not be matched with bank / MPESA records.
Room 201 inventory restored.
Guest: Lady Eleanor Vance (+44 20 7946 0912)'', ''GM Direct Dispatch (+254 700 888 000) & admin@grandaurelia.com'', ''UNREAD'', ''HIGH'', ''2026-09-29 22:50:23'');', 'SUCCESS', 0.10, 1, 'UI_ACTION'),
('h4natru', '01:50:23', 'INSERT INTO notifications (id, recipient_name, recipient_email, recipient_phone, event_type, channel, subject, email_body, sms_body, status, created_at)
VALUES (29, ''Lady Eleanor Vance'', ''eleanor.vance@vanceholdings.co.uk'', ''+44 20 7946 0912'', ''BOOKING_REJECTED'', ''BOTH'', ''Booking Notice: AURELIA-7868 - Grand Aurelia Resort & Suites'', ''Dear Lady Eleanor Vance,

We regret to inform you that your reservation request AURELIA-7868 could not be confirmed at this time and has been rejected by administration.

REASON FOR REJECTION:
• Payment verification could not be matched with bank / MPESA records.

Any advance payments will be credited back via your original payment channel within 24 hours. For questions, please reach our front desk at +254 700 888 999.

Sincerely,
Executive Management Directorate
Grand Aurelia Luxury Resort & Suites'', ''Grand Aurelia Resort & Suites: Notice for booking Ref: AURELIA-7868 (Room 201). Regrettably, your booking has been REJECTED. Reason: Payment verification could not be matched with bank / MPESA records.. Any payments processed will be refunded. Support: +254 700 888 999.'', ''DELIVERED'', ''2026-09-29 22:50:23'');', 'SUCCESS', 0.30, 1, 'UI_ACTION'),
('o7e6haz', '01:50:23', '-- Transaction: Admin Rejection of Reservation
UPDATE bookings SET status = ''Rejected'', notes = CONCAT(notes, '' [Rejected by Admin: Payment verification could not be matched with bank / MPESA records.]'') WHERE id = 1016;
UPDATE rooms SET status = ''Available'' WHERE id = 201;', 'SUCCESS', 0.30, 2, 'UI_ACTION'),
('im76wkg', '01:46:46', '/* CENTRAL SYSTEM DATA EXPORT: Successfully generated & downloaded hotel_db_export.sql (105.3 KB, 11 relational tables + logs + schema metadata) */', 'SUCCESS', 0.60, 11, 'UI_ACTION'),
('6tbaatg', '01:46:44', 'INSERT INTO admin_notification_alerts (id, alert_type, channel, title, sms_content, email_content, recipient, status, priority, created_at)
VALUES (15, ''BOOKING_REJECTED'', ''BOTH'', ''Reservation Rejected: AURELIA-4996'', ''[ADMIN AUDIT] Reservation AURELIA-4996 rejected by GM. Reason: Reservation details incomplete or failed guest identification.. Rejection SMS sent to 0742610425. Room 301 released to Available.'', ''RESERVATION REJECTION AUDIT

Booking AURELIA-4996 was rejected.
Reason: Reservation details incomplete or failed guest identification.
Room 301 inventory restored.
Guest: Lady Eleanor Vance (0742610425)'', ''GM Direct Dispatch (+254 700 888 000) & admin@grandaurelia.com'', ''UNREAD'', ''HIGH'', ''2026-09-29 22:46:44'');', 'SUCCESS', 0.20, 1, 'UI_ACTION'),
('shh9p6v', '01:46:44', 'INSERT INTO notifications (id, recipient_name, recipient_email, recipient_phone, event_type, channel, subject, email_body, sms_body, status, created_at)
VALUES (28, ''Lady Eleanor Vance'', ''eleanor.vance@vanceholdings.co.uk'', ''0742610425'', ''BOOKING_REJECTED'', ''BOTH'', ''Booking Notice: AURELIA-4996 - Grand Aurelia Resort & Suites'', ''Dear Lady Eleanor Vance,

We regret to inform you that your reservation request AURELIA-4996 could not be confirmed at this time and has been rejected by administration.

REASON FOR REJECTION:
• Reservation details incomplete or failed guest identification.

Any advance payments will be credited back via your original payment channel within 24 hours. For questions, please reach our front desk at +254 700 888 999.

Sincerely,
Executive Management Directorate
Grand Aurelia Luxury Resort & Suites'', ''Grand Aurelia Resort & Suites: Notice for booking Ref: AURELIA-4996 (Room 301). Regrettably, your booking has been REJECTED. Reason: Reservation details incomplete or failed guest identification.. Any payments processed will be refunded. Support: +254 700 888 999.'', ''DELIVERED'', ''2026-09-29 22:46:44'');', 'SUCCESS', 0.20, 1, 'UI_ACTION'),
('uwh2e4c', '01:46:44', '-- Transaction: Admin Rejection of Reservation
UPDATE bookings SET status = ''Rejected'', notes = CONCAT(notes, '' [Rejected by Admin: Reservation details incomplete or failed guest identification.]'') WHERE id = 1023;
UPDATE rooms SET status = ''Available'' WHERE id = 301;', 'SUCCESS', 0.20, 2, 'UI_ACTION'),
('6mithkd', '01:45:10', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-01''
      AND b.check_out > ''2026-09-29''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.00, 3, 'UI_ACTION'),
('ws0pngb', '01:45:10', 'SELECT r.* FROM rooms r
WHERE r.status NOT IN (''Under Repair'', ''Maintenance'')
  AND r.max_guests >= 1
  AND r.id NOT IN (
    SELECT b.room_id FROM bookings b 
    WHERE b.status IN (''Confirmed'', ''Checked-In'')
      AND b.check_in < ''2026-10-01''
      AND b.check_out > ''2026-09-29''
  )
ORDER BY r.price ASC;', 'SUCCESS', 0.10, 3, 'UI_ACTION');

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
-- ========================================================
-- Export completed successfully.
-- All relational state, audit logs, and configurations packaged.
-- ========================================================
