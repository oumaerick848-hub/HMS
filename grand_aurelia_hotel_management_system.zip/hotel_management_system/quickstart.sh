#!/bin/bash
echo "=== Grand Aurelia Hotel Management System ==="
echo "1. Initializing MySQL Database..."
echo "To import database schema run:"
echo "mysql -u root -p < database/hotel_db_schema.sql"
echo ""
echo "2. Launching Python Flask Backend:"
cd backend_python_flask
python -m pip install -r requirements.txt
python app.py
