"""
Grand Aurelia - Hotel Management System
Python/Flask Backend with SQLite / MySQL support, Guest Auth & HTML Folio Generation
"""

from flask import Flask, render_template_string, request, jsonify, redirect, url_for, session
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import os

app = Flask(__name__)
app.secret_key = os.urandom(24)

DATABASE = 'hotel_database.db'

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        cursor = conn.cursor()
        
        # Rooms Table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS rooms (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                room_number TEXT UNIQUE NOT NULL,
                room_type TEXT NOT NULL,
                price REAL NOT NULL,
                floor INTEGER NOT NULL,
                status TEXT DEFAULT 'Available',
                bed_type TEXT,
                amenities TEXT
            )
        ''')
        
        # Guests Table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS guests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                full_name TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                phone TEXT,
                id_passport TEXT,
                address TEXT,
                vip_tier TEXT DEFAULT 'Standard',
                notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Guest Accounts Table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS guest_accounts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guest_id INTEGER NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(guest_id) REFERENCES guests(id)
            )
        ''')
        
        # Bookings Table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS bookings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                booking_code TEXT UNIQUE NOT NULL,
                guest_id INTEGER NOT NULL,
                room_id INTEGER NOT NULL,
                check_in TEXT NOT NULL,
                check_out TEXT NOT NULL,
                adults INTEGER DEFAULT 1,
                children INTEGER DEFAULT 0,
                total_amount REAL NOT NULL,
                paid_amount REAL DEFAULT 0,
                status TEXT DEFAULT 'Confirmed',
                payment_method TEXT DEFAULT 'Credit Card',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(guest_id) REFERENCES guests(id),
                FOREIGN KEY(room_id) REFERENCES rooms(id)
            )
        ''')
        
        # Billing Items Table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS billing_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                booking_id INTEGER NOT NULL,
                description TEXT NOT NULL,
                category TEXT NOT NULL,
                amount REAL NOT NULL,
                item_date TEXT NOT NULL,
                FOREIGN KEY(booking_id) REFERENCES bookings(id)
            )
        ''')
        
        # Seed Initial Rooms if empty
        cursor.execute('SELECT COUNT(*) FROM rooms')
        if cursor.fetchone()[0] == 0:
            rooms_data = [
                ('101', 'Standard', 95.0, 1, 'Available', 'Queen Bed', 'WiFi, 43" Smart TV, AC, Safe'),
                ('201', 'Deluxe', 165.0, 2, 'Available', 'King Bed', 'WiFi, Balcony, Minibar, Nespresso'),
                ('301', 'Executive Suite', 290.0, 3, 'Available', 'California King', 'Lounge Access, Marble Bath'),
                ('501', 'Penthouse', 850.0, 5, 'Available', 'Emperor King', 'Plunge Pool, Butler, Skydeck')
            ]
            cursor.executemany('''
                INSERT INTO rooms (room_number, room_type, price, floor, status, bed_type, amenities)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', rooms_data)
            
        conn.commit()

init_db()

@app.route('/')
def home():
    conn = get_db()
    rooms = conn.execute('SELECT * FROM rooms').fetchall()
    return jsonify({
        "system": "Grand Aurelia Hotel Management System",
        "currency": "Ksh",
        "endpoints": {
            "signup": "/api/guest/signup [POST]",
            "login": "/api/guest/login [POST]",
            "rooms": "/api/rooms [GET]",
            "bookings": "/api/bookings [GET, POST]",
            "folio_html": "/guest/folio/<booking_id> [GET]"
        },
        "available_rooms_count": len(rooms)
    })

@app.route('/api/guest/signup', methods=['POST'])
def guest_signup():
    data = request.json or request.form
    full_name = data.get('full_name')
    email = data.get('email', '').strip().lower()
    password = data.get('password')
    phone = data.get('phone', '')
    id_passport = data.get('id_passport', '')
    address = data.get('address', '')

    if not full_name or not email or not password:
        return jsonify({"error": "Full name, email, and password are required"}), 400

    conn = get_db()
    cursor = conn.cursor()

    try:
        cursor.execute('''
            INSERT INTO guests (full_name, email, phone, id_passport, address, vip_tier)
            VALUES (?, ?, ?, ?, ?, 'Standard')
        ''', (full_name, email, phone, id_passport, address))
        guest_id = cursor.lastrowid

        password_hash = generate_password_hash(password)
        cursor.execute('''
            INSERT INTO guest_accounts (guest_id, email, password_hash)
            VALUES (?, ?, ?)
        ''', (guest_id, email, password_hash))

        conn.commit()
        session['guest_id'] = guest_id
        session['email'] = email
        return jsonify({
            "message": "Guest registration successful! Welcome to Grand Aurelia.",
            "guest_id": guest_id,
            "full_name": full_name,
            "email": email,
            "currency": "Ksh"
        }), 201
    except sqlite3.IntegrityError:
        return jsonify({"error": "Account with this email already exists"}), 409

@app.route('/api/guest/login', methods=['POST'])
def guest_login():
    data = request.json or request.form
    email = data.get('email', '').strip().lower()
    password = data.get('password', '')

    conn = get_db()
    account = conn.execute('SELECT * FROM guest_accounts WHERE email = ?', (email,)).fetchone()

    if not account or not check_password_hash(account['password_hash'], password):
        return jsonify({"error": "Invalid email or password"}), 401

    guest = conn.execute('SELECT * FROM guests WHERE id = ?', (account['guest_id'],)).fetchone()
    session['guest_id'] = guest['id']
    session['email'] = email

    return jsonify({
        "message": "Login successful",
        "guest": {
            "id": guest['id'],
            "name": guest['full_name'],
            "email": guest['email'],
            "vip_tier": guest['vip_tier']
        }
    })

@app.route('/guest/folio/<int:booking_id>')
def view_html_folio(booking_id):
    conn = get_db()
    booking = conn.execute('''
        SELECT b.*, g.full_name, g.email, g.phone, g.vip_tier, r.room_number, r.room_type, r.price
        FROM bookings b
        JOIN guests g ON b.guest_id = g.id
        JOIN rooms r ON b.room_id = r.id
        WHERE b.id = ?
    ''', (booking_id,)).fetchone()

    if not booking:
        return "Booking not found", 404

    items = conn.execute('SELECT * FROM billing_items WHERE booking_id = ?', (booking_id,)).fetchall()

    html_template = """
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>Guest Folio - Grand Aurelia</title>
        <style>
            body { font-family: 'Segoe UI', Arial, sans-serif; background: #f8fafc; color: #1e293b; margin: 40px; }
            .folio-box { max-width: 800px; margin: 0 auto; background: #fff; padding: 40px; border-radius: 8px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); }
            .header { display: flex; justify-content: space-between; border-bottom: 2px solid #e2e8f0; padding-bottom: 20px; }
            .title { font-size: 24px; font-weight: bold; color: #0f172a; }
            .sub { color: #64748b; font-size: 14px; }
            table { width: 100%; border-collapse: collapse; margin-top: 24px; }
            th, td { padding: 12px; text-align: left; border-bottom: 1px solid #e2e8f0; }
            th { background: #f1f5f9; font-size: 12px; text-transform: uppercase; color: #475569; }
            .total-box { margin-top: 20px; text-align: right; font-size: 18px; font-weight: bold; }
        </style>
    </head>
    <body>
        <div class="folio-box">
            <div class="header">
                <div>
                    <div class="title">GRAND AURELIA RESORT</div>
                    <div class="sub">Official Guest Stay Folio & Tax Invoice</div>
                </div>
                <div style="text-align: right;">
                    <div><strong>Folio #:</strong> {{ booking['booking_code'] }}</div>
                    <div><strong>Guest:</strong> {{ booking['full_name'] }} ({{ booking['vip_tier'] }})</div>
                    <div><strong>Room:</strong> {{ booking['room_number'] }} ({{ booking['room_type'] }})</div>
                </div>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Description</th>
                        <th>Category</th>
                        <th style="text-align: right;">Amount (Ksh)</th>
                    </tr>
                </thead>
                <tbody>
                    {% for item in items %}
                    <tr>
                        <td>{{ item['item_date'] }}</td>
                        <td>{{ item['description'] }}</td>
                        <td>{{ item['category'] }}</td>
                        <td style="text-align: right;">Ksh {{ "{:,.2f}".format(item['amount']) }}</td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
            <div class="total-box">
                Total Billed: Ksh {{ "{:,.2f}".format(booking['total_amount']) }}
            </div>
        </div>
    </body>
    </html>
    """
    return render_template_string(html_template, booking=booking, items=items)

if __name__ == '__main__':
    print("Hotel Management System running on http://127.0.0.1:5000 (Currency: Ksh)")
    app.run(debug=True, port=5000)
